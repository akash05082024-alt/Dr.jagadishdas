import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { dbManager, Admin, verifyPassword } from './db.js';

const SESSION_SECRET = process.env.SESSION_SECRET || 'super-secret-jwt-session-key-change-in-production';

export interface TokenPayload {
  adminId: string;
  email: string;
  role: string;
  exp: number;
}

// Generate simple secure signed token without requiring external jwt lib
export function generateToken(admin: Admin, expiresInSeconds = 86400 * 7): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload: TokenPayload = {
    adminId: admin.id,
    email: admin.email,
    role: admin.role,
    exp: Math.floor(Date.now() / 1000) + expiresInSeconds,
  };
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(`${header}.${body}`)
    .digest('base64url');

  return `${header}.${body}.${signature}`;
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, signature] = parts;

    const expectedSig = crypto
      .createHmac('sha256', SESSION_SECRET)
      .update(`${header}.${body}`)
      .digest('base64url');

    if (expectedSig !== signature) return null;

    const payload: TokenPayload = JSON.parse(Buffer.from(body, 'base64url').toString('utf-8'));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch (err) {
    return null;
  }
}

// Express auth middleware
export interface AuthenticatedRequest extends Request {
  admin?: Admin;
}

export function requireAdminAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }

  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Session expired or invalid token. Please log in again.' });
  }

  const db = dbManager.get();
  const admin = db.admins.find((a) => a.id === payload.adminId);
  if (!admin) {
    return res.status(401).json({ error: 'User record not found.' });
  }

  req.admin = admin;
  next();
}

// Simple in-memory rate limiter for login & booking endpoints to prevent brute-force / DoS
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();

export function rateLimiter(limit: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown-ip';
    const now = Date.now();
    const record = rateLimitMap.get(ip);

    if (!record || now > record.resetTime) {
      rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs });
      return next();
    }

    if (record.count >= limit) {
      return res.status(429).json({
        error: 'Too many requests. Please wait a few moments and try again.',
      });
    }

    record.count++;
    next();
  };
}
