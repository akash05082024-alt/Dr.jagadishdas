import express, { Request, Response } from 'express';
import {
  dbManager,
  Appointment,
  AppointmentStatus,
  Patient,
  verifyPassword,
  hashPassword,
} from './db.js';
import {
  generateToken,
  requireAdminAuth,
  AuthenticatedRequest,
  rateLimiter,
} from './auth.js';
import { notificationService } from './notificationService.js';

export const apiRouter = express.Router();

// Helper to format 24h "HH:MM" to 12h "hh:mm AM/PM"
function formatTime12(time24: string): string {
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  h = h ? h : 12;
  const hDisplay = h < 10 ? `0${h}` : `${h}`;
  const mDisplay = m < 10 ? `0${m}` : `${m}`;
  return `${hDisplay}:${mDisplay} ${ampm}`;
}

// Generate slot time strings between start and end (24h format, e.g. "10:00" to "13:00")
function generateSlotsForRange(startTime: string, endTime: string, durationMinutes: number): string[] {
  const slots: string[] = [];
  const [startH, startM] = startTime.split(':').map(Number);
  const [endH, endM] = endTime.split(':').map(Number);

  let currentMin = startH * 60 + startM;
  const endTotalMin = endH * 60 + endM;

  while (currentMin + durationMinutes <= endTotalMin) {
    const h = Math.floor(currentMin / 60);
    const m = currentMin % 60;
    const time24 = `${h < 10 ? '0' : ''}${h}:${m < 10 ? '0' : ''}${m}`;
    slots.push(formatTime12(time24));
    currentMin += durationMinutes;
  }

  return slots;
}

// Generate unique sequential appointment ID: APT-2026-0001
function generateNextAppointmentId(appointments: Appointment[]): string {
  const currentYear = new Date().getFullYear();
  const prefix = `APT-${currentYear}-`;
  let maxSeq = 0;

  for (const apt of appointments) {
    if (apt.appointmentId && apt.appointmentId.startsWith(prefix)) {
      const seqStr = apt.appointmentId.replace(prefix, '');
      const num = parseInt(seqStr, 10);
      if (!isNaN(num) && num > maxSeq) {
        maxSeq = num;
      }
    }
  }

  const nextSeq = (maxSeq + 1).toString().padStart(4, '0');
  return `${prefix}${nextSeq}`;
}

/* ==========================================
   PUBLIC PATIENT ENDPOINTS
   ========================================== */

// 1. Get Public Doctor & Clinic Info
apiRouter.get('/public/clinic-data', (req: Request, res: Response) => {
  const db = dbManager.get();
  res.json({
    doctor: db.doctor,
    clinic: db.clinic,
    availabilitySummary: {
      workingDaysText: db.availability.workingDaysText,
      morningShift: db.availability.morningShift,
      eveningShift: db.availability.eveningShift,
      slotDurationMinutes: db.availability.slotDurationMinutes,
      holidays: db.availability.holidays,
    },
  });
});

// 2. Query Available Slots for a given date
apiRouter.get('/public/available-slots', (req: Request, res: Response) => {
  const { date } = req.query;

  if (!date || typeof date !== 'string') {
    return res.status(400).json({ error: 'Date parameter is required in YYYY-MM-DD format.' });
  }

  const db = dbManager.get();
  const targetDate = new Date(`${date}T00:00:00`);
  if (isNaN(targetDate.getTime())) {
    return res.status(400).json({ error: 'Invalid date format. Use YYYY-MM-DD.' });
  }

  const dayOfWeek = targetDate.getDay(); // 0 is Sunday
  const isWorkingDay = db.availability.workingDays.includes(dayOfWeek);

  // Check if holiday or special closed date
  const isHoliday = db.availability.holidays.some((h) => h.date === date);
  const isSpecialClosed = db.availability.specialClosedDates.includes(date);

  if (!isWorkingDay || isHoliday || isSpecialClosed) {
    let reason = 'Doctor is not available on this day.';
    if (!isWorkingDay) reason = 'Clinic is closed on Sundays / non-scheduled consultation days.';
    if (isHoliday) {
      const holiday = db.availability.holidays.find((h) => h.date === date);
      reason = `Clinic is closed for holiday: ${holiday?.reason || 'Public Holiday'}.`;
    }
    return res.json({
      date,
      isOpen: false,
      reason,
      slots: [],
    });
  }

  // Generate slots for configured shifts
  const { morningShift, eveningShift, slotDurationMinutes } = db.availability;
  let allSlotTimes: string[] = [];

  if (morningShift.enabled) {
    allSlotTimes = allSlotTimes.concat(
      generateSlotsForRange(morningShift.startTime, morningShift.endTime, slotDurationMinutes)
    );
  }

  if (eveningShift.enabled) {
    allSlotTimes = allSlotTimes.concat(
      generateSlotsForRange(eveningShift.startTime, eveningShift.endTime, slotDurationMinutes)
    );
  }

  // Find existing bookings on this date that are not cancelled
  const activeBookings = db.appointments.filter(
    (apt) => apt.appointmentDate === date && apt.status !== 'CANCELLED'
  );

  const bookedTimes = new Set(activeBookings.map((apt) => apt.appointmentTime));

  const slots = allSlotTimes.map((time) => {
    const isBooked = bookedTimes.has(time);
    return {
      time,
      available: !isBooked,
      shift: time.includes('AM') || time.startsWith('12:') ? 'Morning' : 'Evening',
    };
  });

  return res.json({
    date,
    isOpen: true,
    totalSlots: slots.length,
    availableSlotsCount: slots.filter((s) => s.available).length,
    slots,
  });
});

// 3. Book an Appointment (Atomic Lock to Prevent Race-Condition Double Booking)
apiRouter.post(
  '/public/appointments/book',
  rateLimiter(15, 60000), // Max 15 booking attempts per minute per IP
  async (req: Request, res: Response) => {
    const {
      patientName,
      patientPhone,
      patientEmail,
      patientAge,
      patientGender,
      patientAddress,
      appointmentDate,
      appointmentTime,
      reason,
    } = req.body;

    // Strict Validations
    if (!patientName || typeof patientName !== 'string' || patientName.trim().length < 2) {
      return res.status(400).json({ error: 'Please enter a valid patient full name.' });
    }

    if (!patientPhone || typeof patientPhone !== 'string' || patientPhone.replace(/\D/g, '').length < 10) {
      return res.status(400).json({ error: 'Please enter a valid 10-digit mobile number.' });
    }

    const ageNum = parseInt(patientAge, 10);
    if (isNaN(ageNum) || ageNum < 1 || ageNum > 120) {
      return res.status(400).json({ error: 'Please enter a valid age between 1 and 120.' });
    }

    if (!patientGender || !['Male', 'Female', 'Other'].includes(patientGender)) {
      return res.status(400).json({ error: 'Please select a valid gender.' });
    }

    if (!appointmentDate || !/^\d{4}-\d{2}-\d{2}$/.test(appointmentDate)) {
      return res.status(400).json({ error: 'Please select a valid appointment date (YYYY-MM-DD).' });
    }

    if (!appointmentTime || typeof appointmentTime !== 'string') {
      return res.status(400).json({ error: 'Please select a valid consultation time slot.' });
    }

    if (!reason || typeof reason !== 'string' || reason.trim().length < 3) {
      return res.status(400).json({ error: 'Please specify the main health concern or reason for visit.' });
    }

    try {
      // Execute atomically inside Mutex Lock to eliminate double booking race condition!
      const result = await dbManager.withLock(async () => {
        const db = dbManager.get();

        // 1. Double-booking check
        const existingBooking = db.appointments.find(
          (apt) =>
            apt.appointmentDate === appointmentDate &&
            apt.appointmentTime === appointmentTime &&
            apt.status !== 'CANCELLED'
        );

        if (existingBooking) {
          return {
            success: false,
            code: 409,
            error: 'Sorry, this time slot has just been booked. Please select another time.',
          };
        }

        // 2. Check maximum daily appointment limit
        const activeDailyCount = db.appointments.filter(
          (apt) => apt.appointmentDate === appointmentDate && apt.status !== 'CANCELLED'
        ).length;

        if (activeDailyCount >= db.availability.maxAppointmentsPerDay) {
          return {
            success: false,
            code: 400,
            error: 'The doctor has reached the maximum appointment capacity for this date. Please choose the next available day.',
          };
        }

        // 3. Find or create patient record
        const normalizedPhone = patientPhone.trim();
        let patient = db.patients.find((p) => p.phone === normalizedPhone);

        if (!patient) {
          patient = {
            id: `pat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            name: patientName.trim(),
            phone: normalizedPhone,
            email: (patientEmail || '').trim(),
            age: ageNum,
            gender: patientGender,
            address: (patientAddress || '').trim(),
            firstVisitDate: appointmentDate,
            totalAppointments: 1,
          };
          db.patients.push(patient);
        } else {
          patient.totalAppointments += 1;
          patient.age = ageNum;
          if (patientEmail) patient.email = patientEmail.trim();
          if (patientAddress) patient.address = patientAddress.trim();
        }

        // 4. Generate unique Appointment ID: APT-2026-XXXX
        const appointmentId = generateNextAppointmentId(db.appointments);

        const newAppointment: Appointment = {
          id: `apt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          appointmentId,
          doctorId: db.doctor.id,
          patientId: patient.id,
          patientName: patientName.trim(),
          patientPhone: normalizedPhone,
          patientEmail: (patientEmail || '').trim(),
          patientAge: ageNum,
          patientGender: patientGender,
          patientAddress: (patientAddress || '').trim(),
          appointmentDate,
          appointmentTime,
          reason: reason.trim(),
          status: 'CONFIRMED', // Confirmed directly per clinic requirements
          consultationFee: db.doctor.consultationFee,
          bookedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        db.appointments.push(newAppointment);

        return {
          success: true,
          code: 201,
          appointment: newAppointment,
          doctorName: db.doctor.name,
          clinicName: db.clinic.clinicName,
        };
      });

      if (!result.success) {
        return res.status(result.code).json({ error: result.error });
      }

      // Dispatch SMS / WhatsApp Notifications in the background asynchronously
      if (result.appointment) {
        notificationService
          .notifyNewBooking({
            appointment: result.appointment,
            doctorName: result.doctorName!,
            clinicName: result.clinicName!,
          })
          .catch((err) => {
            console.error('[Notification Dispatch Error]:', err);
          });
      }

      return res.status(201).json({
        success: true,
        message: 'Appointment booked successfully.',
        appointment: result.appointment,
      });
    } catch (err: any) {
      console.error('[Booking Error]:', err);
      return res.status(500).json({ error: 'Appointment could not be booked. Please try again.' });
    }
  }
);

// 4. Get Appointment Confirmation details by Appointment ID (e.g. APT-2026-0001)
apiRouter.get('/public/appointments/:appointmentId', (req: Request, res: Response) => {
  const { appointmentId } = req.params;
  const db = dbManager.get();

  const apt = db.appointments.find(
    (a) => a.appointmentId.toUpperCase() === appointmentId.toUpperCase()
  );

  if (!apt) {
    return res.status(404).json({ error: 'Appointment record not found.' });
  }

  return res.json({
    appointment: apt,
    doctor: {
      name: db.doctor.name,
      degrees: db.doctor.degrees,
      specialization: db.doctor.specialization,
      consultationFee: apt.consultationFee,
    },
    clinic: {
      clinicName: db.clinic.clinicName,
      addressLine1: db.clinic.addressLine1,
      addressLine2: db.clinic.addressLine2,
      city: db.clinic.city,
      pincode: db.clinic.pincode,
      phonePrimary: db.clinic.phonePrimary,
      googleMapsUrl: db.clinic.googleMapsUrl,
    },
  });
});

// 5. Patient Cancel Appointment (requires matching phone for verification)
apiRouter.post('/public/appointments/:appointmentId/cancel', async (req: Request, res: Response) => {
  const { appointmentId } = req.params;
  const { phone } = req.body;

  if (!phone || typeof phone !== 'string') {
    return res.status(400).json({ error: 'Patient mobile number is required to verify cancellation.' });
  }

  const result = await dbManager.withLock(async () => {
    const db = dbManager.get();
    const apt = db.appointments.find(
      (a) => a.appointmentId.toUpperCase() === appointmentId.toUpperCase()
    );

    if (!apt) {
      return { success: false, code: 404, error: 'Appointment not found.' };
    }

    const cleanInputPhone = phone.replace(/\D/g, '');
    const cleanRecordPhone = apt.patientPhone.replace(/\D/g, '');

    if (!cleanRecordPhone.endsWith(cleanInputPhone) && !cleanInputPhone.endsWith(cleanRecordPhone)) {
      return { success: false, code: 403, error: 'Provided phone number does not match booking record.' };
    }

    if (apt.status === 'CANCELLED') {
      return { success: false, code: 400, error: 'This appointment is already cancelled.' };
    }

    apt.status = 'CANCELLED';
    apt.updatedAt = new Date().toISOString();

    return { success: true, code: 200, appointment: apt };
  });

  if (!result.success) {
    return res.status(result.code).json({ error: result.error });
  }

  return res.json({
    success: true,
    message: 'Appointment has been cancelled successfully.',
    appointment: result.appointment,
  });
});

/* ==========================================
   ADMIN AUTH & PROFILE ENDPOINTS
   ========================================== */

// Admin Login
apiRouter.post('/admin/login', rateLimiter(10, 60000), (req: Request, res: Response) => {
  const { identifier, password } = req.body; // email or mobile

  if (!identifier || !password) {
    return res.status(400).json({ error: 'Please enter email/mobile and password.' });
  }

  const db = dbManager.get();
  const cleanId = identifier.trim().toLowerCase();

  const admin = db.admins.find(
    (a) => a.email.toLowerCase() === cleanId || a.mobile.replace(/\D/g, '') === cleanId.replace(/\D/g, '')
  );

  if (!admin) {
    return res.status(401).json({ error: 'Invalid credentials. Please verify your email/mobile and password.' });
  }

  const isValid = verifyPassword(password, admin.passwordHash, admin.salt);
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid credentials. Please verify your email/mobile and password.' });
  }

  const token = generateToken(admin);

  return res.json({
    success: true,
    token,
    admin: {
      id: admin.id,
      name: admin.name,
      email: admin.email,
      mobile: admin.mobile,
      role: admin.role,
    },
  });
});

// Admin Me
apiRouter.get('/admin/me', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const admin = req.admin!;
  return res.json({
    admin: {
      id: admin.id,
      name: admin.name,
      email: admin.email,
      mobile: admin.mobile,
      role: admin.role,
    },
  });
});

// Change Password
apiRouter.post('/admin/change-password', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  const admin = req.admin!;

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Current password and new password are required.' });
  }

  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  }

  const isValid = verifyPassword(currentPassword, admin.passwordHash, admin.salt);
  if (!isValid) {
    return res.status(400).json({ error: 'Incorrect current password.' });
  }

  await dbManager.withLock(() => {
    const db = dbManager.get();
    const dbAdmin = db.admins.find((a) => a.id === admin.id);
    if (dbAdmin) {
      const { hash, salt } = hashPassword(newPassword);
      dbAdmin.passwordHash = hash;
      dbAdmin.salt = salt;
    }
  });

  return res.json({ success: true, message: 'Password updated successfully.' });
});

/* ==========================================
   ADMIN DASHBOARD & APPOINTMENTS
   ========================================== */

// Dashboard Statistics & Analytics
apiRouter.get('/admin/dashboard-stats', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = dbManager.get();
  const appointments = db.appointments;
  const todayStr = new Date().toISOString().split('T')[0];

  const todayAppointments = appointments.filter((a) => a.appointmentDate === todayStr);
  const upcomingAppointments = appointments.filter(
    (a) => a.appointmentDate >= todayStr && a.status !== 'CANCELLED' && a.status !== 'COMPLETED'
  );

  const pendingCount = appointments.filter((a) => a.status === 'PENDING').length;
  const confirmedCount = appointments.filter((a) => a.status === 'CONFIRMED').length;
  const completedCount = appointments.filter((a) => a.status === 'COMPLETED').length;
  const cancelledCount = appointments.filter((a) => a.status === 'CANCELLED').length;
  const noShowCount = appointments.filter((a) => a.status === 'NO-SHOW').length;

  // Distinct patients today
  const todayPatientPhones = new Set(todayAppointments.map((a) => a.patientPhone));

  // Past 7 days booking trend
  const past7Days: Array<{ date: string; label: string; count: number }> = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const label = d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const count = appointments.filter((a) => a.appointmentDate === dateStr && a.status !== 'CANCELLED').length;
    past7Days.push({ date: dateStr, label, count });
  }

  return res.json({
    todayAppointmentsCount: todayAppointments.length,
    upcomingAppointmentsCount: upcomingAppointments.length,
    totalAppointmentsCount: appointments.length,
    pendingCount,
    confirmedCount,
    completedCount,
    cancelledCount,
    noShowCount,
    todayPatientCount: todayPatientPhones.size,
    totalPatientsCount: db.patients.length,
    past7Days,
    statusBreakdown: {
      CONFIRMED: confirmedCount,
      PENDING: pendingCount,
      COMPLETED: completedCount,
      CANCELLED: cancelledCount,
      'NO-SHOW': noShowCount,
    },
  });
});

// All Appointments with search and filters
apiRouter.get('/admin/appointments', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { date, status, search } = req.query;
  const db = dbManager.get();
  let list = [...db.appointments];

  if (date && typeof date === 'string') {
    list = list.filter((a) => a.appointmentDate === date);
  }

  if (status && typeof status === 'string' && status !== 'ALL') {
    list = list.filter((a) => a.status === status);
  }

  if (search && typeof search === 'string') {
    const q = search.trim().toLowerCase();
    list = list.filter(
      (a) =>
        a.patientName.toLowerCase().includes(q) ||
        a.patientPhone.toLowerCase().includes(q) ||
        a.appointmentId.toLowerCase().includes(q) ||
        a.reason.toLowerCase().includes(q)
    );
  }

  // Sort: by date descending, then time ascending
  list.sort((a, b) => {
    if (a.appointmentDate !== b.appointmentDate) {
      return b.appointmentDate.localeCompare(a.appointmentDate);
    }
    return a.appointmentTime.localeCompare(b.appointmentTime);
  });

  return res.json({ appointments: list, count: list.length });
});

// Update Appointment Status, Notes, or Reschedule
apiRouter.patch('/admin/appointments/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { status, doctorNotes, appointmentDate, appointmentTime } = req.body;

  const result = await dbManager.withLock(async () => {
    const db = dbManager.get();
    const apt = db.appointments.find((a) => a.id === id || a.appointmentId === id);

    if (!apt) {
      return { success: false, code: 404, error: 'Appointment not found.' };
    }

    if (status && ['PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO-SHOW'].includes(status)) {
      apt.status = status as AppointmentStatus;
    }

    if (doctorNotes !== undefined) {
      apt.doctorNotes = doctorNotes;
    }

    // Handle Rescheduling
    if (appointmentDate && appointmentTime) {
      // Check collision
      const collision = db.appointments.find(
        (a) =>
          a.id !== apt.id &&
          a.appointmentDate === appointmentDate &&
          a.appointmentTime === appointmentTime &&
          a.status !== 'CANCELLED'
      );
      if (collision) {
        return { success: false, code: 409, error: 'Selected reschedule time slot is already booked.' };
      }
      apt.appointmentDate = appointmentDate;
      apt.appointmentTime = appointmentTime;
    }

    apt.updatedAt = new Date().toISOString();
    return { success: true, code: 200, appointment: apt };
  });

  if (!result.success) {
    return res.status(result.code).json({ error: result.error });
  }

  return res.json({ success: true, appointment: result.appointment });
});

// Create Walk-in / Phone Appointment from Admin Panel
apiRouter.post('/admin/appointments/create', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const {
    patientName,
    patientPhone,
    patientEmail,
    patientAge,
    patientGender,
    appointmentDate,
    appointmentTime,
    reason,
    status = 'CONFIRMED',
    doctorNotes,
  } = req.body;

  if (!patientName || !patientPhone || !appointmentDate || !appointmentTime) {
    return res.status(400).json({ error: 'Patient name, phone, date, and time slot are required.' });
  }

  const result = await dbManager.withLock(async () => {
    const db = dbManager.get();

    // Collision check
    const existing = db.appointments.find(
      (a) =>
        a.appointmentDate === appointmentDate &&
        a.appointmentTime === appointmentTime &&
        a.status !== 'CANCELLED'
    );
    if (existing) {
      return { success: false, code: 409, error: 'This time slot is already booked.' };
    }

    // Patient lookup
    let patient = db.patients.find((p) => p.phone === patientPhone.trim());
    if (!patient) {
      patient = {
        id: `pat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: patientName.trim(),
        phone: patientPhone.trim(),
        email: (patientEmail || '').trim(),
        age: parseInt(patientAge, 10) || 30,
        gender: patientGender || 'Male',
        firstVisitDate: appointmentDate,
        totalAppointments: 1,
      };
      db.patients.push(patient);
    } else {
      patient.totalAppointments += 1;
    }

    const appointmentId = generateNextAppointmentId(db.appointments);
    const newApt: Appointment = {
      id: `apt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      appointmentId,
      doctorId: db.doctor.id,
      patientId: patient.id,
      patientName: patientName.trim(),
      patientPhone: patientPhone.trim(),
      patientEmail: (patientEmail || '').trim(),
      patientAge: parseInt(patientAge, 10) || 30,
      patientGender: patientGender || 'Male',
      appointmentDate,
      appointmentTime,
      reason: reason || 'Walk-in Consultation',
      status: status || 'CONFIRMED',
      consultationFee: db.doctor.consultationFee,
      doctorNotes: doctorNotes || '',
      bookedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.appointments.push(newApt);
    return { success: true, code: 201, appointment: newApt };
  });

  if (!result.success) {
    return res.status(result.code).json({ error: result.error });
  }

  return res.status(201).json({ success: true, appointment: result.appointment });
});

/* ==========================================
   PATIENTS MANAGEMENT
   ========================================== */

apiRouter.get('/admin/patients', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { search } = req.query;
  const db = dbManager.get();
  let list = [...db.patients];

  if (search && typeof search === 'string') {
    const q = search.trim().toLowerCase();
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.phone.toLowerCase().includes(q) ||
        (p.email && p.email.toLowerCase().includes(q))
    );
  }

  return res.json({ patients: list, count: list.length });
});

apiRouter.get('/admin/patients/:id', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const db = dbManager.get();
  const patient = db.patients.find((p) => p.id === id || p.phone === id);

  if (!patient) {
    return res.status(404).json({ error: 'Patient profile not found.' });
  }

  const patientAppointments = db.appointments
    .filter((a) => a.patientId === patient.id || a.patientPhone === patient.phone)
    .sort((a, b) => b.appointmentDate.localeCompare(a.appointmentDate));

  return res.json({
    patient,
    appointments: patientAppointments,
  });
});

/* ==========================================
   AVAILABILITY & SETTINGS
   ========================================== */

apiRouter.get('/admin/availability', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = dbManager.get();
  return res.json({ availability: db.availability });
});

apiRouter.put('/admin/availability', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const newAvailability = req.body;

  await dbManager.withLock(() => {
    const db = dbManager.get();
    db.availability = {
      ...db.availability,
      ...newAvailability,
    };
  });

  return res.json({ success: true, availability: dbManager.get().availability });
});

apiRouter.get('/admin/settings', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = dbManager.get();
  return res.json({
    doctor: db.doctor,
    clinic: db.clinic,
    notificationsConfig: db.notificationsConfig,
  });
});

apiRouter.put('/admin/settings', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { doctor, clinic, notificationsConfig } = req.body;

  await dbManager.withLock(() => {
    const db = dbManager.get();
    if (doctor) db.doctor = { ...db.doctor, ...doctor };
    if (clinic) db.clinic = { ...db.clinic, ...clinic };
    if (notificationsConfig) db.notificationsConfig = { ...db.notificationsConfig, ...notificationsConfig };
  });

  return res.json({ success: true, message: 'Settings saved successfully.' });
});

/* ==========================================
   NOTIFICATION LOGS & TESTING
   ========================================== */

apiRouter.get('/admin/notification-logs', requireAdminAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = dbManager.get();
  return res.json({ logs: db.notificationLogs });
});

apiRouter.post('/admin/test-notification', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { channel, recipientPhone } = req.body;
  const db = dbManager.get();

  const phone = recipientPhone || db.notificationsConfig.doctorNotificationPhone;
  const testMessage =
    `[Test Notification - Dr. Jagadish Das Portal]\n` +
    `Channel: ${channel}\n` +
    `Time: ${new Date().toLocaleTimeString()}\n` +
    `System status: Online and operational.`;

  try {
    const fakeApt: Appointment = {
      id: 'test_apt',
      appointmentId: 'APT-TEST-0001',
      doctorId: db.doctor.id,
      patientId: 'test_pat',
      patientName: 'Test Recipient',
      patientPhone: phone,
      patientEmail: '',
      patientAge: 35,
      patientGender: 'Male',
      appointmentDate: new Date().toISOString().split('T')[0],
      appointmentTime: '10:00 AM',
      reason: 'Notification Gateway Verification',
      status: 'CONFIRMED',
      consultationFee: db.doctor.consultationFee,
      bookedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await notificationService.notifyNewBooking({
      appointment: fakeApt,
      doctorName: db.doctor.name,
      clinicName: db.clinic.clinicName,
    });

    return res.json({ success: true, message: `Test notification dispatched to ${phone}` });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to dispatch test notification' });
  }
});
