import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface Admin {
  id: string;
  email: string;
  mobile: string;
  passwordHash: string;
  salt: string;
  name: string;
  role: string;
  createdAt: string;
}

export interface DoctorProfile {
  id: string;
  name: string;
  degrees: string;
  specialization: string;
  experienceYears: number;
  registrationNumber: string;
  consultationFee: number;
  languages: string[];
  about: string;
  services: string[];
  photoUrl: string;
  clinicId: string;
}

export interface ClinicSettings {
  id: string;
  clinicName: string;
  tagline: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  pincode: string;
  landmark: string;
  phonePrimary: string;
  phoneEmergency: string;
  email: string;
  googleMapsUrl: string;
  googleMapsEmbedUrl: string;
  parkingInfo: string;
}

export interface AvailabilitySettings {
  workingDays: number[]; // 0 = Sun, 1 = Mon, ..., 6 = Sat
  workingDaysText: string;
  slotDurationMinutes: number;
  maxAppointmentsPerDay: number;
  morningShift: {
    enabled: boolean;
    startTime: string; // "10:00"
    endTime: string;   // "13:00"
  };
  eveningShift: {
    enabled: boolean;
    startTime: string; // "17:00"
    endTime: string;   // "20:00"
  };
  breakTimes: Array<{
    title: string;
    startTime: string;
    endTime: string;
  }>;
  holidays: Array<{
    date: string; // "YYYY-MM-DD"
    reason: string;
  }>;
  specialClosedDates: string[]; // "YYYY-MM-DD"
}

export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO-SHOW';

export interface Appointment {
  id: string;
  appointmentId: string; // e.g. "APT-2026-0001"
  doctorId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string;
  patientAge: number;
  patientGender: 'Male' | 'Female' | 'Other';
  patientAddress?: string;
  appointmentDate: string; // "YYYY-MM-DD"
  appointmentTime: string; // "10:30 AM"
  reason: string;
  status: AppointmentStatus;
  consultationFee: number;
  doctorNotes?: string;
  prescriptionSummary?: string;
  bookedAt: string;
  updatedAt: string;
}

export interface Patient {
  id: string;
  name: string;
  phone: string;
  email: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  address?: string;
  firstVisitDate: string;
  totalAppointments: number;
  notes?: string;
}

export interface NotificationLog {
  id: string;
  appointmentId: string;
  recipientType: 'DOCTOR' | 'PATIENT';
  recipientPhone: string;
  channel: 'WHATSAPP' | 'SMS';
  provider: string;
  status: 'SENT' | 'FAILED' | 'FALLBACK_SENT';
  message: string;
  sentAt: string;
  errorMessage?: string;
}

export interface NotificationSettings {
  whatsappEnabled: boolean;
  smsFallbackEnabled: boolean;
  whatsappApiKeyPlaceholder: string;
  whatsappPhoneNumberIdPlaceholder: string;
  smsApiKeyPlaceholder: string;
  smsSenderIdPlaceholder: string;
  doctorNotificationPhone: string;
}

export interface DatabaseSchema {
  admins: Admin[];
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  availability: AvailabilitySettings;
  notificationsConfig: NotificationSettings;
  appointments: Appointment[];
  patients: Patient[];
  notificationLogs: NotificationLog[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'clinic_db.json');

// Password utility
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, generatedSalt, 1000, 64, 'sha512').toString('hex');
  return { hash, salt: generatedSalt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const verify = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return verify === hash;
}

// Initial default seed state
function getInitialDatabase(): DatabaseSchema {
  const { hash, salt } = hashPassword('DoctorSecurePass2026!');

  return {
    admins: [
      {
        id: 'admin_1',
        email: 'admin@drjagadishdas.com',
        mobile: '+919876543210',
        passwordHash: hash,
        salt,
        name: 'Dr. Jagadish Das',
        role: 'SUPER_ADMIN',
        createdAt: '2026-01-01T00:00:00.000Z',
      },
    ],
    doctor: {
      id: 'doc_1',
      name: 'Dr. Jagadish Das',
      degrees: 'MBBS',
      specialization: 'General Physician & Clinical Practitioner',
      experienceYears: 12,
      registrationNumber: 'MCI/WBMC-2014-72941',
      consultationFee: 500,
      languages: ['English', 'Bengali', 'Hindi'],
      about:
        'Dr. Jagadish Das (MBBS) is an experienced and compassionate medical practitioner dedicated to comprehensive family healthcare, preventive diagnosis, fever & infection care, and chronic lifestyle disease management. With over 12 years of patient-first clinical experience, he offers evidence-based treatment plans tailored to each patient.',
      services: [
        'Primary Medical Consultation',
        'Hypertension & Blood Pressure Care',
        'Diabetes Screening & Management',
        'Acute Fever, Flu & Infection Care',
        'Routine Health Checkup & Screenings',
        'Pediatric & Geriatric Outpatient Care',
        'Preventive Health Counseling',
        'Prescription Review & Lab Interpretation',
      ],
      photoUrl: '', // Will use elegant clinical SVG doctor portrait if empty
      clinicId: 'clinic_1',
    },
    clinic: {
      id: 'clinic_1',
      clinicName: 'Arogya Health & Consultation Chamber',
      tagline: 'Quality Outpatient Medical Care & Family Healthcare',
      addressLine1: 'Ground Floor, Suite 104, Medanta Arcade',
      addressLine2: 'Park View Enclave, 42 Central Road (Near City Hospital)',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700029',
      landmark: 'Opposite City Central Park Gate No. 2',
      phonePrimary: '+91 98765 43210',
      phoneEmergency: '+91 98765 43211',
      email: 'care@drjagadishdas.com',
      googleMapsUrl: 'https://maps.google.com/?q=Park+View+Enclave+Central+Road+Kolkata',
      googleMapsEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.7!2d88.35!3d22.52!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjLCsDMxJzEyLjAiTiA4OMKwMjEnMDAuMCJF!5e0!3m2!1sen!2sin!4v1650000000000',
      parkingInfo: 'Dedicated basement parking available for 2-wheelers and 4-wheelers. Ramp access for wheelchair assistance.',
    },
    availability: {
      workingDays: [1, 2, 3, 4, 5, 6], // Mon - Sat (0=Sun)
      workingDaysText: 'Monday to Saturday',
      slotDurationMinutes: 15,
      maxAppointmentsPerDay: 40,
      morningShift: {
        enabled: true,
        startTime: '10:00',
        endTime: '13:00',
      },
      eveningShift: {
        enabled: true,
        startTime: '17:00',
        endTime: '20:00',
      },
      breakTimes: [
        {
          title: 'Afternoon Clinic Recess',
          startTime: '13:00',
          endTime: '17:00',
        },
      ],
      holidays: [
        {
          date: '2026-10-02',
          reason: 'National Holiday (Gandhi Jayanti)',
        },
      ],
      specialClosedDates: [],
    },
    notificationsConfig: {
      whatsappEnabled: true,
      smsFallbackEnabled: true,
      whatsappApiKeyPlaceholder: process.env.WHATSAPP_API_KEY || 'WHATSAPP_ENV_TOKEN_SET',
      whatsappPhoneNumberIdPlaceholder: process.env.WHATSAPP_PHONE_NUMBER_ID || '1084920491024',
      smsApiKeyPlaceholder: process.env.SMS_API_KEY || 'SMS_GATEWAY_TOKEN_SET',
      smsSenderIdPlaceholder: process.env.SMS_SENDER_ID || 'DRJDAS',
      doctorNotificationPhone: process.env.DOCTOR_PHONE_NUMBER || '+919876543210',
    },
    patients: [
      {
        id: 'pat_1',
        name: 'Sourav Ganguly',
        phone: '+919830112233',
        email: 'sourav.g@example.com',
        age: 44,
        gender: 'Male',
        address: 'Behala, Kolkata',
        firstVisitDate: '2026-09-10',
        totalAppointments: 2,
        notes: 'History of seasonal allergies and mild hypertension. Advised lifestyle modifications.',
      },
      {
        id: 'pat_2',
        name: 'Priyanka Banerjee',
        phone: '+919831223344',
        email: 'priyanka.b@example.com',
        age: 32,
        gender: 'Female',
        address: 'Ballygunge, Kolkata',
        firstVisitDate: '2026-09-15',
        totalAppointments: 1,
        notes: 'Follow-up for thyroid panel check. Prescribed vitamins.',
      },
      {
        id: 'pat_3',
        name: 'Amitabh Roy',
        phone: '+919832334455',
        email: '',
        age: 58,
        gender: 'Male',
        address: 'Salt Lake Sector 1, Kolkata',
        firstVisitDate: '2026-09-20',
        totalAppointments: 1,
        notes: 'Diabetic management check. Fasting sugar 132 mg/dL. HbA1c advised.',
      },
    ],
    appointments: [
      {
        id: 'apt_1',
        appointmentId: 'APT-2026-0001',
        doctorId: 'doc_1',
        patientId: 'pat_1',
        patientName: 'Sourav Ganguly',
        patientPhone: '+919830112233',
        patientEmail: 'sourav.g@example.com',
        patientAge: 44,
        patientGender: 'Male',
        patientAddress: 'Behala, Kolkata',
        appointmentDate: '2026-09-28',
        appointmentTime: '10:00 AM',
        reason: 'Seasonal cough, throat irritation and routine BP check',
        status: 'CONFIRMED',
        consultationFee: 500,
        doctorNotes: 'Vitals stable on arrival. Advised throat gargle and cetirizine if required.',
        bookedAt: '2026-09-26T09:15:00.000Z',
        updatedAt: '2026-09-26T10:00:00.000Z',
      },
      {
        id: 'apt_2',
        appointmentId: 'APT-2026-0002',
        doctorId: 'doc_1',
        patientId: 'pat_2',
        patientName: 'Priyanka Banerjee',
        patientPhone: '+919831223344',
        patientEmail: 'priyanka.b@example.com',
        patientAge: 32,
        patientGender: 'Female',
        patientAddress: 'Ballygunge, Kolkata',
        appointmentDate: '2026-09-28',
        appointmentTime: '11:15 AM',
        reason: 'General weakness and fatigue consultation',
        status: 'PENDING',
        consultationFee: 500,
        bookedAt: '2026-09-27T14:30:00.000Z',
        updatedAt: '2026-09-27T14:30:00.000Z',
      },
      {
        id: 'apt_3',
        appointmentId: 'APT-2026-0003',
        doctorId: 'doc_1',
        patientId: 'pat_3',
        patientName: 'Amitabh Roy',
        patientPhone: '+919832334455',
        patientEmail: '',
        patientAge: 58,
        patientGender: 'Male',
        patientAddress: 'Salt Lake Sector 1, Kolkata',
        appointmentDate: '2026-09-28',
        appointmentTime: '05:30 PM',
        reason: 'Blood sugar review and medication adjustment',
        status: 'CONFIRMED',
        consultationFee: 500,
        bookedAt: '2026-09-27T16:00:00.000Z',
        updatedAt: '2026-09-27T16:00:00.000Z',
      },
      {
        id: 'apt_4',
        appointmentId: 'APT-2026-0004',
        doctorId: 'doc_1',
        patientId: 'pat_1',
        patientName: 'Sourav Ganguly',
        patientPhone: '+919830112233',
        patientEmail: 'sourav.g@example.com',
        patientAge: 44,
        patientGender: 'Male',
        appointmentDate: '2026-09-25',
        appointmentTime: '10:30 AM',
        reason: 'Initial consultation for persistent mild fever',
        status: 'COMPLETED',
        consultationFee: 500,
        doctorNotes: 'Viral prodrome. Paracetamol prescribed. Advised plenty of fluids.',
        bookedAt: '2026-09-24T11:00:00.000Z',
        updatedAt: '2026-09-25T11:00:00.000Z',
      },
    ],
    notificationLogs: [
      {
        id: 'notif_1',
        appointmentId: 'APT-2026-0001',
        recipientType: 'DOCTOR',
        recipientPhone: '+919876543210',
        channel: 'WHATSAPP',
        provider: 'Meta Cloud API',
        status: 'SENT',
        message: 'New Appointment Received - APT-2026-0001 | Patient: Sourav Ganguly',
        sentAt: '2026-09-26T09:15:05.000Z',
      },
      {
        id: 'notif_2',
        appointmentId: 'APT-2026-0001',
        recipientType: 'PATIENT',
        recipientPhone: '+919830112233',
        channel: 'WHATSAPP',
        provider: 'Meta Cloud API',
        status: 'SENT',
        message: 'Your appointment with Dr. Jagadish Das has been successfully booked. APT-2026-0001',
        sentAt: '2026-09-26T09:15:06.000Z',
      },
      {
        id: 'notif_3',
        appointmentId: 'APT-2026-0002',
        recipientType: 'DOCTOR',
        recipientPhone: '+919876543210',
        channel: 'WHATSAPP',
        provider: 'Meta Cloud API',
        status: 'SENT',
        message: 'New Appointment Received - APT-2026-0002 | Patient: Priyanka Banerjee',
        sentAt: '2026-09-27T14:30:04.000Z',
      },
      {
        id: 'notif_4',
        appointmentId: 'APT-2026-0002',
        recipientType: 'PATIENT',
        recipientPhone: '+919831223344',
        channel: 'SMS',
        provider: 'Fast2SMS Gateway',
        status: 'FALLBACK_SENT',
        message: 'WhatsApp timeout - Fallback SMS delivered: Dr. Jagadish Das appointment APT-2026-0002',
        sentAt: '2026-09-27T14:30:08.000Z',
        errorMessage: 'WhatsApp recipient device offline, dispatched via SMS fallback successfully.',
      },
    ],
  };
}

class DatabaseManager {
  private db: DatabaseSchema;
  private isSaving: boolean = false;
  private lockPromise: Promise<void> = Promise.resolve();

  constructor() {
    this.ensureDirectory();
    this.db = this.loadDatabase();
  }

  private ensureDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return parsed;
      }
    } catch (e) {
      console.error('[DB] Failed to load existing database file, falling back to seed:', e);
    }
    const initial = getInitialDatabase();
    this.persist(initial);
    return initial;
  }

  private persist(data: DatabaseSchema) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('[DB] Failed to save database file:', e);
    }
  }

  // Mutex lock to execute atomic operations (essential for double-booking prevention)
  public async withLock<T>(action: () => Promise<T> | T): Promise<T> {
    let release: () => void;
    const nextLock = new Promise<void>((resolve) => {
      release = resolve;
    });
    const currentLock = this.lockPromise;
    this.lockPromise = currentLock.then(() => nextLock);

    await currentLock;
    try {
      return await action();
    } finally {
      this.persist(this.db);
      release!();
    }
  }

  public get(): DatabaseSchema {
    return this.db;
  }

  public save() {
    this.persist(this.db);
  }
}

export const dbManager = new DatabaseManager();
