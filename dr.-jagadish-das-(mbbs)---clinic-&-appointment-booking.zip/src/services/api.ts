import {
  DoctorProfile,
  ClinicSettings,
  AvailableSlotsResponse,
  Appointment,
  Patient,
  AvailabilitySettings,
  NotificationLog,
  DashboardStats,
  NotificationSettings,
} from '../types/clinic';

const TOKEN_KEY = 'dr_jdas_admin_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken() {
  localStorage.removeItem(TOKEN_KEY);
}

function getAuthHeaders(): HeadersInit {
  const token = getStoredToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

// Public API
export async function fetchPublicClinicData(): Promise<{
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  availabilitySummary: {
    workingDaysText: string;
    morningShift: { enabled: boolean; startTime: string; endTime: string };
    eveningShift: { enabled: boolean; startTime: string; endTime: string };
    slotDurationMinutes: number;
    holidays: Array<{ date: string; reason: string }>;
  };
}> {
  const res = await fetch('/api/public/clinic-data');
  if (!res.ok) throw new Error('Failed to load clinic information');
  return res.json();
}

export async function fetchAvailableSlots(date: string): Promise<AvailableSlotsResponse> {
  const res = await fetch(`/api/public/available-slots?date=${encodeURIComponent(date)}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to fetch slots' }));
    throw new Error(err.error || 'Failed to fetch slots');
  }
  return res.json();
}

export interface BookingPayload {
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  patientAge: number;
  patientGender: 'Male' | 'Female' | 'Other';
  patientAddress?: string;
  appointmentDate: string;
  appointmentTime: string;
  reason: string;
}

export async function bookAppointment(payload: BookingPayload): Promise<{
  success: boolean;
  message: string;
  appointment: Appointment;
}> {
  const res = await fetch('/api/public/appointments/book', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Appointment could not be booked. Please try again.');
  }
  return data;
}

export async function getAppointmentDetails(appointmentId: string): Promise<{
  appointment: Appointment;
  doctor: Partial<DoctorProfile>;
  clinic: Partial<ClinicSettings>;
}> {
  const res = await fetch(`/api/public/appointments/${encodeURIComponent(appointmentId)}`);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Appointment record not found');
  }
  return data;
}

export async function cancelPatientAppointment(appointmentId: string, phone: string): Promise<{
  success: boolean;
  message: string;
  appointment: Appointment;
}> {
  const res = await fetch(`/api/public/appointments/${encodeURIComponent(appointmentId)}/cancel`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phone }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to cancel appointment');
  }
  return data;
}

// Admin API
export async function loginAdmin(identifier: string, password: string) {
  const res = await fetch('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, password }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Login failed');
  }
  setStoredToken(data.token);
  return data;
}

export async function getAdminMe() {
  const res = await fetch('/api/admin/me', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Session invalid');
  return res.json();
}

export async function getDashboardStats(): Promise<DashboardStats> {
  const res = await fetch('/api/admin/dashboard-stats', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch dashboard metrics');
  return res.json();
}

export async function getAdminAppointments(params?: {
  date?: string;
  status?: string;
  search?: string;
}): Promise<{ appointments: Appointment[]; count: number }> {
  const query = new URLSearchParams();
  if (params?.date) query.set('date', params.date);
  if (params?.status) query.set('status', params.status);
  if (params?.search) query.set('search', params.search);

  const res = await fetch(`/api/admin/appointments?${query.toString()}`, {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch appointments');
  return res.json();
}

export async function updateAppointment(
  id: string,
  update: {
    status?: string;
    doctorNotes?: string;
    appointmentDate?: string;
    appointmentTime?: string;
  }
) {
  const res = await fetch(`/api/admin/appointments/${id}`, {
    method: 'PATCH',
    headers: getAuthHeaders(),
    body: JSON.stringify(update),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update appointment');
  return data;
}

export async function createAdminAppointment(payload: any) {
  const res = await fetch('/api/admin/appointments/create', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to create appointment');
  return data;
}

export async function getAdminPatients(search?: string): Promise<{ patients: Patient[]; count: number }> {
  const query = search ? `?search=${encodeURIComponent(search)}` : '';
  const res = await fetch(`/api/admin/patients${query}`, {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch patient records');
  return res.json();
}

export async function getAdminPatientDetail(id: string): Promise<{ patient: Patient; appointments: Appointment[] }> {
  const res = await fetch(`/api/admin/patients/${id}`, {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to load patient history');
  return res.json();
}

export async function getAdminAvailability(): Promise<{ availability: AvailabilitySettings }> {
  const res = await fetch('/api/admin/availability', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch availability settings');
  return res.json();
}

export async function updateAdminAvailability(availability: Partial<AvailabilitySettings>) {
  const res = await fetch('/api/admin/availability', {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(availability),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to save availability');
  return data;
}

export async function getAdminSettings(): Promise<{
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  notificationsConfig: NotificationSettings;
}> {
  const res = await fetch('/api/admin/settings', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch settings');
  return res.json();
}

export async function updateAdminSettings(settings: {
  doctor?: Partial<DoctorProfile>;
  clinic?: Partial<ClinicSettings>;
  notificationsConfig?: Partial<NotificationSettings>;
}) {
  const res = await fetch('/api/admin/settings', {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(settings),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Failed to update settings');
  return data;
}

export async function changeAdminPassword(currentPassword: string, newPassword: string) {
  const res = await fetch('/api/admin/change-password', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ currentPassword, newPassword }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Password update failed');
  return data;
}

export async function getAdminNotificationLogs(): Promise<{ logs: NotificationLog[] }> {
  const res = await fetch('/api/admin/notification-logs', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch notification history');
  return res.json();
}

export async function testNotification(channel: 'WHATSAPP' | 'SMS', recipientPhone?: string) {
  const res = await fetch('/api/admin/test-notification', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ channel, recipientPhone }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Notification test failed');
  return data;
}
