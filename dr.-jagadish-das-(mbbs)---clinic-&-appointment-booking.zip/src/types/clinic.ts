export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO-SHOW';

export interface DoctorProfile {
  id: string;
  name: string;
  degrees: string;
  specialization: string;
  experienceYears: number;
  registrationNumber: string;
  consultationFee: number;
  languages: string[];
  about: string;
  services: string[];
  photoUrl: string;
  clinicId: string;
}

export interface ClinicSettings {
  id: string;
  clinicName: string;
  tagline: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  pincode: string;
  landmark: string;
  phonePrimary: string;
  phoneEmergency: string;
  email: string;
  googleMapsUrl: string;
  googleMapsEmbedUrl: string;
  parkingInfo: string;
}

export interface AvailabilityShift {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

export interface AvailabilitySettings {
  workingDays: number[];
  workingDaysText: string;
  slotDurationMinutes: number;
  maxAppointmentsPerDay: number;
  morningShift: AvailabilityShift;
  eveningShift: AvailabilityShift;
  breakTimes: Array<{
    title: string;
    startTime: string;
    endTime: string;
  }>;
  holidays: Array<{
    date: string;
    reason: string;
  }>;
  specialClosedDates: string[];
}

export interface SlotInfo {
  time: string;
  available: boolean;
  shift: 'Morning' | 'Evening';
}

export interface AvailableSlotsResponse {
  date: string;
  isOpen: boolean;
  reason?: string;
  totalSlots: number;
  availableSlotsCount: number;
  slots: SlotInfo[];
}

export interface Appointment {
  id: string;
  appointmentId: string;
  doctorId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string;
  patientAge: number;
  patientGender: 'Male' | 'Female' | 'Other';
  patientAddress?: string;
  appointmentDate: string;
  appointmentTime: string;
  reason: string;
  status: AppointmentStatus;
  consultationFee: number;
  doctorNotes?: string;
  prescriptionSummary?: string;
  bookedAt: string;
  updatedAt: string;
}

export interface Patient {
  id: string;
  name: string;
  phone: string;
  email: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  address?: string;
  firstVisitDate: string;
  totalAppointments: number;
  notes?: string;
}

export interface NotificationLog {
  id: string;
  appointmentId: string;
  recipientType: 'DOCTOR' | 'PATIENT';
  recipientPhone: string;
  channel: 'WHATSAPP' | 'SMS';
  provider: string;
  status: 'SENT' | 'FAILED' | 'FALLBACK_SENT';
  message: string;
  sentAt: string;
  errorMessage?: string;
}

export interface NotificationSettings {
  whatsappEnabled: boolean;
  smsFallbackEnabled: boolean;
  whatsappApiKeyPlaceholder: string;
  whatsappPhoneNumberIdPlaceholder: string;
  smsApiKeyPlaceholder: string;
  smsSenderIdPlaceholder: string;
  doctorNotificationPhone: string;
}

export interface DashboardStats {
  todayAppointmentsCount: number;
  upcomingAppointmentsCount: number;
  totalAppointmentsCount: number;
  pendingCount: number;
  confirmedCount: number;
  completedCount: number;
  cancelledCount: number;
  noShowCount: number;
  todayPatientCount: number;
  totalPatientsCount: number;
  past7Days: Array<{ date: string; label: string; count: number }>;
  statusBreakdown: Record<AppointmentStatus, number>;
}
