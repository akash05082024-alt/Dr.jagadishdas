import React, { useState } from 'react';
import { Stethoscope, Lock, Phone, MapPin, Mail, Shield, Info, X } from 'lucide-react';
import { DoctorProfile, ClinicSettings } from '../types/clinic';

interface FooterProps {
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  onOpenAdmin: () => void;
  onOpenBooking: () => void;
  onOpenLookup: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  doctor,
  clinic,
  onOpenAdmin,
  onOpenBooking,
  onOpenLookup,
}) => {
  const [showDeploymentModal, setShowDeploymentModal] = useState(false);

  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5 text-white">
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
                <Stethoscope className="w-4 h-4" />
              </div>
              <span className="text-base font-bold tracking-tight">
                {doctor.name}
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed text-xs">
              {doctor.degrees} · {doctor.specialization}. Dedicated clinical outpatient family healthcare, chronic illness management, and preventative screening.
            </p>
            <div className="text-slate-500 font-mono text-[11px]">
              Reg: {doctor.registrationNumber}
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Patient Services
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onOpenBooking}
                  className="hover:text-teal-400 transition-colors cursor-pointer"
                >
                  Book In-Person Appointment
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenLookup}
                  className="hover:text-teal-400 transition-colors cursor-pointer"
                >
                  Check Existing Booking Status
                </button>
              </li>
              <li>
                <a href="#about-doctor" className="hover:text-teal-400 transition-colors">
                  Doctor Background & Degrees
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-teal-400 transition-colors">
                  Outpatient Medical Services
                </a>
              </li>
              <li>
                <a href="#clinic-location" className="hover:text-teal-400 transition-colors">
                  Chamber Address & Directions
                </a>
              </li>
            </ul>
          </div>

          {/* Clinic Chamber Contact */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Chamber Contact
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>
                  {clinic.clinicName}, {clinic.addressLine1}, {clinic.city} - {clinic.pincode}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-teal-400 shrink-0" />
                <a href={`tel:${clinic.phonePrimary}`} className="hover:text-white tabular-nums">
                  {clinic.phonePrimary}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-teal-400 shrink-0" />
                <a href={`mailto:${clinic.email}`} className="hover:text-white">
                  {clinic.email}
                </a>
              </div>
            </div>
          </div>

          {/* Portals & Security */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Administration & System
            </h4>
            <p className="text-slate-400 text-xs">
              Secure portal for doctor and clinic staff to manage daily appointment slots, patient logs, and SMS/WhatsApp notifications.
            </p>
            <div className="flex flex-col gap-2 pt-1">
              <button
                onClick={onOpenAdmin}
                className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-teal-400" />
                <span>Doctor Admin Portal</span>
              </button>

              <button
                onClick={() => setShowDeploymentModal(true)}
                className="w-full py-1.5 px-3 rounded-lg bg-slate-800/40 hover:bg-slate-800 text-slate-400 text-[11px] flex items-center justify-center gap-1 transition-colors cursor-pointer"
              >
                <Info className="w-3 h-3 text-slate-400" />
                <span>Production Deployment & API Specs</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Strip */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} Dr. Jagadish Das (MBBS). All rights reserved. Medical registration verifiable through State Medical Council.
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-teal-500" /> Secure HIPAA/Data Compliant Architecture
            </span>
          </div>
        </div>
      </div>

      {/* Production Deployment Instructions Modal */}
      {showDeploymentModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 text-slate-300 w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-700 overflow-hidden animate-in fade-in duration-150">
            <div className="bg-slate-800 px-6 py-4 flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-teal-400" />
                <h3 className="font-bold text-white text-base">Production Deployment & API Setup Guide</h3>
              </div>
              <button
                onClick={() => setShowDeploymentModal(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs leading-relaxed">
              <p>
                This application is engineered with an Express backend, atomic mutex lock double-booking prevention, and a modular WhatsApp / SMS notification adapter. Below are the production setup specifications:
              </p>

              <div className="space-y-2">
                <h4 className="font-bold text-white text-sm">1. Environment Variables (.env)</h4>
                <pre className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px] text-teal-300 overflow-x-auto">
{`# Meta WhatsApp Cloud API
WHATSAPP_API_KEY="your_meta_system_user_token"
WHATSAPP_PHONE_NUMBER_ID="your_whatsapp_phone_number_id"
WHATSAPP_BUSINESS_ACCOUNT_ID="your_waba_id"

# SMS Gateway (Fast2SMS / Msg91 / Twilio)
SMS_API_KEY="your_sms_gateway_api_key"
SMS_SENDER_ID="DRJDAS"

# Doctor Admin Credentials
DOCTOR_PHONE_NUMBER="+919876543210"
ADMIN_EMAIL="admin@drjagadishdas.com"
SESSION_SECRET="your-cryptographic-jwt-secret-key"`}
                </pre>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-white text-sm">2. Database Architecture</h4>
                <p>
                  Structured JSON persistence in <code>data/clinic_db.json</code> with synchronous mutex locking. Easily swappable to PostgreSQL or Firestore by updating <code>server/db.ts</code>.
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-white text-sm">3. WhatsApp & SMS Fallback Architecture</h4>
                <p>
                  Implemented in <code>server/notificationService.ts</code>. When a booking occurs, WhatsApp Meta Cloud API is attempted first; on timeout/failure, automatic SMS fallback is instantly triggered and recorded in notification logs.
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold text-white text-sm">4. Google Maps & HTTPS</h4>
                <p>
                  Replace the embed URL in Admin Settings with your custom Google Maps Place Embed URL. In production, serve behind Nginx or Cloudflare SSL.
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-800/80 border-t border-slate-700 flex justify-end">
              <button
                onClick={() => setShowDeploymentModal(false)}
                className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl"
              >
                Close Guide
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
