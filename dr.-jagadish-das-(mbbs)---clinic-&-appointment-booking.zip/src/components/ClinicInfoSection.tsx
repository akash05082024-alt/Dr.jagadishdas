import React from 'react';
import {
  MapPin,
  Clock,
  Phone,
  Car,
  DollarSign,
  Navigation,
  ShieldAlert,
  CalendarCheck,
  Mail,
  ExternalLink,
} from 'lucide-react';
import { ClinicSettings, DoctorProfile } from '../types/clinic';

interface ClinicInfoSectionProps {
  clinic: ClinicSettings;
  doctor: DoctorProfile;
  timingsText: string;
  onBookClick: () => void;
}

export const ClinicInfoSection: React.FC<ClinicInfoSectionProps> = ({
  clinic,
  doctor,
  timingsText,
  onBookClick,
}) => {
  return (
    <section id="clinic-location" className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-teal-700 mb-2">
            Chamber Location & Visiting Hours
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Clinic Information & Directions
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Conveniently accessible clinic chamber with dedicated patient parking and wheelchair ramp.
          </p>
        </div>

        {/* Bento Grid: Clinic Details + Interactive Map */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Clinic Specifications & Emergency Info */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Primary Chamber Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-7 space-y-5">
              
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                  Primary Consultation Chamber
                </span>
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
                  {clinic.clinicName}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {clinic.tagline}
                </p>
              </div>

              {/* Specs Rows */}
              <div className="space-y-4 pt-4 border-t border-slate-200 text-sm">
                
                {/* Full Address */}
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-slate-900">Chamber Address</div>
                    <div className="text-slate-600 text-xs sm:text-sm mt-0.5">
                      {clinic.addressLine1}
                    </div>
                    <div className="text-slate-600 text-xs sm:text-sm">
                      {clinic.addressLine2}
                    </div>
                    <div className="text-slate-600 text-xs sm:text-sm">
                      {clinic.city}, {clinic.state} - {clinic.pincode}
                    </div>
                    <div className="text-teal-800 text-xs font-semibold mt-1">
                      Landmark: {clinic.landmark}
                    </div>
                  </div>
                </div>

                {/* Opening Hours */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200/70">
                  <Clock className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-slate-900">Consultation Timings</div>
                    <div className="text-slate-800 font-semibold text-xs sm:text-sm mt-0.5">
                      {timingsText}
                    </div>
                    <div className="text-slate-500 text-xs mt-0.5">
                      Morning: 10:00 AM – 01:00 PM · Evening: 05:00 PM – 08:00 PM
                    </div>
                    <div className="text-rose-600 text-xs font-medium mt-0.5">
                      Sunday: Chamber Closed
                    </div>
                  </div>
                </div>

                {/* Consultation Fee */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200/70">
                  <DollarSign className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-slate-900">Consultation Fee</div>
                    <div className="text-slate-800 font-bold text-sm mt-0.5">
                      ₹{doctor.consultationFee} <span className="text-xs font-normal text-slate-500">(Direct in-person consultation)</span>
                    </div>
                  </div>
                </div>

                {/* Parking Information Placeholder */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200/70">
                  <Car className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-slate-900">Parking & Accessibility</div>
                    <p className="text-slate-600 text-xs sm:text-sm mt-0.5 leading-relaxed">
                      {clinic.parkingInfo}
                    </p>
                  </div>
                </div>

                {/* Phone & Contact */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200/70">
                  <Phone className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-slate-900">Appointment & Inquiry Desk</div>
                    <div className="text-slate-900 font-bold text-sm mt-0.5 tabular-nums">
                      {clinic.phonePrimary}
                    </div>
                    <div className="text-slate-500 text-xs">
                      Email: {clinic.email}
                    </div>
                  </div>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex flex-wrap items-center gap-3">
                <a
                  href={clinic.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 text-xs sm:text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
                >
                  <Navigation className="w-4 h-4 text-teal-400" />
                  <span>Get Directions in Google Maps</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                </a>

                <a
                  href={`tel:${clinic.phonePrimary.replace(/\s+/g, '')}`}
                  className="px-4 py-3 text-xs sm:text-sm font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <Phone className="w-4 h-4 text-teal-600" />
                  <span>Call Reception</span>
                </a>
              </div>

            </div>

            {/* Emergency Notice Section */}
            <div className="p-5 rounded-2xl bg-amber-50/80 border border-amber-200/90 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs sm:text-sm font-bold text-amber-900">
                  Emergency Medical Notice
                </h4>
                <p className="text-xs text-amber-800 leading-relaxed">
                  This clinic chamber is designated for scheduled outpatient consultations and primary family care. In the event of severe acute medical emergencies, sudden chest pain, difficulty breathing, or severe trauma, please immediately visit the nearest hospital emergency room (City Hospital ER) or call ambulance service 108 / 112.
                </p>
                <div className="text-xs font-bold text-amber-900 pt-1">
                  Chamber Emergency Hotline: {clinic.phoneEmergency}
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT: Google Maps Interactive Location Section */}
          <div className="lg:col-span-6 space-y-4">
            
            <div className="bg-slate-100 border border-slate-200 rounded-3xl overflow-hidden shadow-md flex flex-col">
              
              {/* Map Top Bar */}
              <div className="bg-white px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-teal-600" />
                  <span className="text-xs font-bold text-slate-800">
                    Location: Medanta Arcade, Central Road, Kolkata
                  </span>
                </div>
                <a
                  href={clinic.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-teal-700 hover:text-teal-900 flex items-center gap-1"
                >
                  <span>Open Full Map</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Embedded Interactive Map Frame with clean fallback */}
              <div className="relative w-full h-[380px] sm:h-[440px] bg-slate-200">
                <iframe
                  title="Dr. Jagadish Das Clinic Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14740.12!2d88.35!3d22.52!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjLCsDMxJzEyLjAiTiA4OMKwMjEnMDAuMCJF!5e0!3m2!1sen!2sin!4v1650000000000!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />

                {/* Floating Directions Badge inside Map */}
                <div className="absolute bottom-4 left-4 right-4 sm:right-auto bg-white/95 backdrop-blur-md rounded-2xl p-4 border border-slate-200/90 shadow-lg max-w-sm">
                  <div className="text-xs font-bold text-slate-900">{clinic.clinicName}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                    {clinic.addressLine1}, {clinic.landmark}
                  </div>
                  <a
                    href={clinic.googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Get Directions</span>
                  </a>
                </div>
              </div>

            </div>

            {/* Quick Action below Map */}
            <div className="p-4 bg-teal-50/60 rounded-2xl border border-teal-200/60 flex items-center justify-between text-xs">
              <span className="text-slate-700 font-medium">
                Planning to visit today? Check available slots online first.
              </span>
              <button
                onClick={onBookClick}
                className="px-3.5 py-1.5 font-bold text-white bg-teal-700 hover:bg-teal-800 rounded-lg cursor-pointer shrink-0"
              >
                Book Appointment
              </button>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
