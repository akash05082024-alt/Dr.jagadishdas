import React from 'react';
import {
  Award,
  BookOpen,
  Calendar,
  Clock,
  Languages,
  MapPin,
  ShieldCheck,
  Stethoscope,
  CheckCircle,
  FileText,
  DollarSign,
} from 'lucide-react';
import { DoctorAvatar } from './DoctorAvatar';
import { DoctorProfile, ClinicSettings } from '../types/clinic';

interface DoctorProfileSectionProps {
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  timingsText: string;
  onBookClick: () => void;
}

export const DoctorProfileSection: React.FC<DoctorProfileSectionProps> = ({
  doctor,
  clinic,
  timingsText,
  onBookClick,
}) => {
  return (
    <section id="about-doctor" className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-teal-700 mb-2">
            Physician Profile & Credentials
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            About {doctor.name} ({doctor.degrees})
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Dedicated outpatient medical practice focusing on diagnostic accuracy, patient empathy, and long-term wellness.
          </p>
        </div>

        {/* Profile Card & Detailed Credentials Bento Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Doctor Portrait & Primary Quick Specs */}
          <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-7 space-y-6">
            <div className="flex flex-col items-center text-center">
              <DoctorAvatar size="xl" showBadge={true} />
              
              <h3 className="mt-4 text-xl font-bold text-slate-900">
                {doctor.name}
              </h3>
              <div className="text-sm font-semibold text-teal-700">
                {doctor.degrees}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {doctor.specialization}
              </div>
            </div>

            {/* Quick Specs List */}
            <div className="space-y-3 pt-4 border-t border-slate-200/80 text-sm">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/50">
                <span className="text-slate-500 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-teal-600" /> Medical Council Reg.
                </span>
                <span className="font-semibold text-slate-800 text-xs sm:text-sm">
                  {doctor.registrationNumber}
                </span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/50">
                <span className="text-slate-500 flex items-center gap-2">
                  <Award className="w-4 h-4 text-teal-600" /> Clinical Experience
                </span>
                <span className="font-semibold text-slate-800 tabular-nums">
                  {doctor.experienceYears}+ Years
                </span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/50">
                <span className="text-slate-500 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-teal-600" /> Consultation Fee
                </span>
                <span className="font-bold text-teal-800 tabular-nums">
                  ₹{doctor.consultationFee}
                </span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/50">
                <span className="text-slate-500 flex items-center gap-2">
                  <Languages className="w-4 h-4 text-teal-600" /> Languages Spoken
                </span>
                <span className="font-semibold text-slate-800 text-xs sm:text-sm">
                  {doctor.languages.join(', ')}
                </span>
              </div>

              <div className="flex items-start justify-between py-1.5">
                <span className="text-slate-500 flex items-center gap-2 shrink-0">
                  <Clock className="w-4 h-4 text-teal-600" /> Timings
                </span>
                <span className="font-semibold text-slate-800 text-right text-xs sm:text-sm">
                  {timingsText}
                </span>
              </div>
            </div>

            <button
              onClick={onBookClick}
              className="w-full py-3 px-4 text-sm font-bold text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment Now</span>
            </button>
          </div>

          {/* RIGHT: Detailed About, Professional Philosophy & Services */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* About Prose Block */}
            <div className="bg-slate-50/60 rounded-3xl p-6 sm:p-8 border border-slate-200/80">
              <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-teal-600" />
                Professional Background & Philosophy
              </h3>
              <p className="text-slate-700 leading-relaxed text-base">
                {doctor.about}
              </p>
              
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6 border-t border-slate-200">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Patient-Centric Care</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Thorough physical evaluation, active listening to clinical history, and clear treatment explanations.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Preventive Focus</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Screening for silent risk factors including hypertension, high fasting glucose, and lipid profiles.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Services Offered Bento */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Stethoscope className="w-5 h-5 text-teal-600" />
                  Clinical Services & Consultation Scope
                </h3>
                <span className="text-xs text-slate-500">Outpatient Services</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {doctor.services.map((service, index) => (
                  <div
                    key={index}
                    className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-teal-300 hover:shadow-xs transition-all flex items-start gap-3"
                  >
                    <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-xs font-bold tabular-nums">0{index + 1}</span>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-800">{service}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Comprehensive clinical evaluation, diagnostic review, and tailored management.
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Clinic Chamber Note */}
            <div className="p-5 rounded-2xl bg-teal-50/70 border border-teal-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-teal-900 uppercase tracking-wider">
                  Chamber Affiliation
                </div>
                <div className="text-sm font-bold text-slate-900">
                  {clinic.clinicName}
                </div>
                <div className="text-xs text-slate-600">
                  {clinic.addressLine1}, {clinic.landmark}, {clinic.city} - {clinic.pincode}
                </div>
              </div>

              <button
                onClick={onBookClick}
                className="px-5 py-2.5 text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 rounded-lg shadow-xs whitespace-nowrap cursor-pointer"
              >
                Book Consultation
              </button>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
