import React from 'react';

interface DoctorAvatarProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showBadge?: boolean;
}

export const DoctorAvatar: React.FC<DoctorAvatarProps> = ({
  className = '',
  size = 'lg',
  showBadge = true,
}) => {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-20 h-20',
    lg: 'w-36 h-36',
    xl: 'w-52 h-52 md:w-64 md:h-64',
  };

  return (
    <div className={`relative inline-block ${className}`}>
      <div
        className={`${sizeClasses[size]} rounded-2xl overflow-hidden bg-gradient-to-b from-teal-50 via-teal-100/60 to-slate-100 border border-teal-200/80 shadow-md flex items-center justify-center relative group`}
      >
        {/* Medical Physician Illustration Container */}
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full object-cover transform scale-105"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Subtle medical cross watermark in background */}
          <path
            d="M85 30h30v140H85z M30 85h140v30H30z"
            fill="currentColor"
            className="text-teal-500/10"
          />

          {/* Shoulders & White Coat */}
          <path
            d="M30 195 C 40 145, 70 135, 100 135 C 130 135, 160 145, 170 195 Z"
            fill="#0F766E"
          />
          {/* White Doctor's Lab Coat Lapels */}
          <path
            d="M50 195 L80 140 L100 170 L120 140 L150 195 Z"
            fill="#FFFFFF"
            stroke="#E2E8F0"
            strokeWidth="1.5"
          />
          {/* Shirt / Inner Tie */}
          <path d="M92 142 L108 142 L104 165 L96 165 Z" fill="#0D9488" />
          
          {/* Stethoscope Tubing around neck */}
          <path
            d="M75 140 C 75 170, 85 185, 100 185 C 115 185, 125 170, 125 140"
            stroke="#334155"
            strokeWidth="3.5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Stethoscope Chest Piece */}
          <circle cx="100" cy="186" r="6" fill="#94A3B8" stroke="#1E293B" strokeWidth="2" />
          <circle cx="100" cy="186" r="2.5" fill="#0F766E" />

          {/* Neck */}
          <path d="M88 110 L112 110 L112 135 L88 135 Z" fill="#E2A176" />
          {/* Face */}
          <ellipse cx="100" cy="90" rx="32" ry="38" fill="#F0B58C" />
          {/* Hair */}
          <path
            d="M68 85 C 66 60, 85 52, 100 52 C 115 52, 134 60, 132 85 C 128 72, 120 62, 100 62 C 80 62, 72 72, 68 85 Z"
            fill="#27272A"
          />
          {/* Ears */}
          <circle cx="67" cy="92" r="6" fill="#E2A176" />
          <circle cx="133" cy="92" r="6" fill="#E2A176" />
          {/* Eyes & Eyebrows */}
          <ellipse cx="88" cy="88" rx="3" ry="2.2" fill="#1E293B" />
          <ellipse cx="112" cy="88" rx="3" ry="2.2" fill="#1E293B" />
          <path d="M83 82 Q 88 80 93 83" stroke="#27272A" strokeWidth="2" strokeLinecap="round" fill="none" />
          <path d="M107 83 Q 112 80 117 82" stroke="#27272A" strokeWidth="2" strokeLinecap="round" fill="none" />
          {/* Wireframe Doctor Glasses */}
          <rect x="80" y="82" width="16" height="12" rx="3" stroke="#0F766E" strokeWidth="1.5" fill="none" />
          <rect x="104" y="82" width="16" height="12" rx="3" stroke="#0F766E" strokeWidth="1.5" fill="none" />
          <line x1="96" y1="87" x2="104" y2="87" stroke="#0F766E" strokeWidth="1.5" />
          {/* Nose */}
          <path d="M100 88 L98 98 L103 98" stroke="#C98862" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          {/* Friendly Smile */}
          <path d="M92 108 Q 100 115 108 108" stroke="#9A3412" strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>

        <div className="absolute inset-0 bg-gradient-to-t from-teal-900/15 via-transparent to-transparent pointer-events-none" />
      </div>

      {showBadge && (
        <div className="absolute -bottom-2 -right-2 bg-white text-teal-800 text-[11px] font-semibold px-2 py-0.5 rounded-md shadow border border-teal-200 flex items-center gap-1">
          <svg className="w-3.5 h-3.5 text-teal-600 shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
              clipRule="evenodd"
            />
          </svg>
          <span>MBBS Verified</span>
        </div>
      )}
    </div>
  );
};
