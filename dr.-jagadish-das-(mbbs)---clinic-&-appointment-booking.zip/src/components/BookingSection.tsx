import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  User,
  Phone,
  Mail,
  MapPin,
  FileText,
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Loader2,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { DoctorProfile, ClinicSettings, SlotInfo, Appointment } from '../types/clinic';
import { fetchAvailableSlots, bookAppointment, BookingPayload } from '../services/api';

interface BookingSectionProps {
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  onBookingSuccess: (appointment: Appointment) => void;
}

export const BookingSection: React.FC<BookingSectionProps> = ({
  doctor,
  clinic,
  onBookingSuccess,
}) => {
  // Step state: 1 = Date & Slot, 2 = Patient Details, 3 = Confirmation Summary Review
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Selected booking parameters
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    // Default to tomorrow or today
    const now = new Date();
    return now.toISOString().split('T')[0];
  });
  const [selectedSlot, setSelectedSlot] = useState<string>('');

  // Slots fetching state
  const [slotsLoading, setSlotsLoading] = useState<boolean>(false);
  const [slotsData, setSlotsData] = useState<{
    isOpen: boolean;
    reason?: string;
    slots: SlotInfo[];
    availableCount: number;
  }>({
    isOpen: true,
    slots: [],
    availableCount: 0,
  });

  // Patient Form Fields
  const [formData, setFormData] = useState({
    patientName: '',
    patientPhone: '',
    patientEmail: '',
    patientAge: '',
    patientGender: 'Male' as 'Male' | 'Female' | 'Other',
    patientAddress: '',
    reason: '',
  });

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load available slots whenever selectedDate changes
  useEffect(() => {
    let isMounted = true;
    async function loadSlots() {
      if (!selectedDate) return;
      setSlotsLoading(true);
      setErrorMessage(null);
      try {
        const res = await fetchAvailableSlots(selectedDate);
        if (isMounted) {
          setSlotsData({
            isOpen: res.isOpen,
            reason: res.reason,
            slots: res.slots || [],
            availableCount: res.availableSlotsCount || 0,
          });
          // Reset slot selection if previous slot not available in newly selected day
          setSelectedSlot('');
        }
      } catch (err: any) {
        if (isMounted) {
          setSlotsData({
            isOpen: false,
            reason: err?.message || 'Could not load slots for this date',
            slots: [],
            availableCount: 0,
          });
        }
      } finally {
        if (isMounted) setSlotsLoading(false);
      }
    }
    loadSlots();
    return () => {
      isMounted = false;
    };
  }, [selectedDate]);

  // Generate quick next 7 days for the fast date selector strip
  const dateOptions = Array.from({ length: 10 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const dateStr = d.toISOString().split('T')[0];
    const isToday = i === 0;
    const isTomorrow = i === 1;
    const dayName = isToday
      ? 'Today'
      : isTomorrow
      ? 'Tomorrow'
      : d.toLocaleDateString('en-US', { weekday: 'short' });
    const formatted = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const isSunday = d.getDay() === 0;
    return { dateStr, dayName, formatted, isSunday };
  });

  const handleDateSelect = (dateStr: string) => {
    setSelectedDate(dateStr);
  };

  const handleSlotSelect = (time: string, available: boolean) => {
    if (!available) return;
    setSelectedSlot(time);
    setErrorMessage(null);
  };

  const validateStep1 = () => {
    if (!selectedDate) {
      setErrorMessage('Please choose a consultation date.');
      return false;
    }
    if (!selectedSlot) {
      setErrorMessage('Please select an available consultation time slot.');
      return false;
    }
    setErrorMessage(null);
    return true;
  };

  const validateStep2 = () => {
    if (!formData.patientName.trim() || formData.patientName.trim().length < 2) {
      setErrorMessage('Please enter the patient full name (at least 2 characters).');
      return false;
    }
    const cleanPhone = formData.patientPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return false;
    }
    const ageNum = parseInt(formData.patientAge, 10);
    if (isNaN(ageNum) || ageNum < 1 || ageNum > 120) {
      setErrorMessage('Please enter a valid patient age between 1 and 120.');
      return false;
    }
    if (!formData.reason.trim() || formData.reason.trim().length < 3) {
      setErrorMessage('Please describe the main reason for visit or health concern.');
      return false;
    }
    setErrorMessage(null);
    return true;
  };

  const handleProceedToStep2 = () => {
    if (validateStep1()) {
      setStep(2);
    }
  };

  const handleProceedToStep3 = () => {
    if (validateStep2()) {
      setStep(3);
    }
  };

  const handleFinalBooking = async () => {
    setErrorMessage(null);
    setIsSubmitting(true);

    const payload: BookingPayload = {
      patientName: formData.patientName.trim(),
      patientPhone: formData.patientPhone.trim(),
      patientEmail: formData.patientEmail.trim() || undefined,
      patientAge: parseInt(formData.patientAge, 10),
      patientGender: formData.patientGender,
      patientAddress: formData.patientAddress.trim() || undefined,
      appointmentDate: selectedDate,
      appointmentTime: selectedSlot,
      reason: formData.reason.trim(),
    };

    try {
      const res = await bookAppointment(payload);
      if (res.success && res.appointment) {
        onBookingSuccess(res.appointment);
        // Reset form
        setStep(1);
        setSelectedSlot('');
        setFormData({
          patientName: '',
          patientPhone: '',
          patientEmail: '',
          patientAge: '',
          patientGender: 'Male',
          patientAddress: '',
          reason: '',
        });
      }
    } catch (err: any) {
      // Handles 409 slot taken or other errors
      setErrorMessage(err.message || 'Appointment could not be booked. Please try again.');
      // If slot conflict, send back to slot selection
      if (err.message?.includes('slot has just been booked')) {
        setStep(1);
        // Refresh slots
        const refreshed = await fetchAvailableSlots(selectedDate);
        setSlotsData({
          isOpen: refreshed.isOpen,
          reason: refreshed.reason,
          slots: refreshed.slots || [],
          availableCount: refreshed.availableSlotsCount || 0,
        });
        setSelectedSlot('');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const morningSlots = slotsData.slots.filter((s) => s.shift === 'Morning');
  const eveningSlots = slotsData.slots.filter((s) => s.shift === 'Evening');

  // Format date display
  const formattedSelectedDate = new Date(`${selectedDate}T00:00:00`).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <section id="book-appointment" className="py-16 sm:py-20 bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-teal-700">
            Real-Time Slot Reservation
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Book Your Consultation
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            Select an open appointment slot with <span className="font-semibold text-slate-900">{doctor.name} ({doctor.degrees})</span>.
          </p>
        </div>

        {/* Stepper Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between max-w-md mx-auto relative">
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -translate-y-1/2 -z-0" />
            
            {/* Step 1 */}
            <div className="relative z-10 flex flex-col items-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  step >= 1 ? 'bg-teal-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'
                }`}
              >
                1
              </div>
              <span className="text-[11px] font-semibold text-slate-700 mt-1">Date & Time</span>
            </div>

            {/* Step 2 */}
            <div className="relative z-10 flex flex-col items-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  step >= 2 ? 'bg-teal-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'
                }`}
              >
                2
              </div>
              <span className="text-[11px] font-semibold text-slate-700 mt-1">Patient Details</span>
            </div>

            {/* Step 3 */}
            <div className="relative z-10 flex flex-col items-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  step === 3 ? 'bg-teal-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'
                }`}
              >
                3
              </div>
              <span className="text-[11px] font-semibold text-slate-700 mt-1">Confirm Booking</span>
            </div>
          </div>
        </div>

        {/* Global Error Banner */}
        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-start gap-3 animate-in fade-in duration-200">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="font-semibold">Attention Needed</div>
              <div>{errorMessage}</div>
            </div>
          </div>
        )}

        {/* Main Card Container */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md">
          
          {/* ================= STEP 1: DATE & TIME SELECTION ================= */}
          {step === 1 && (
            <div className="space-y-8 animate-in fade-in duration-200">
              
              {/* Date Strip Picker */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-teal-600" />
                    1. Select Consultation Date
                  </label>
                  <input
                    type="date"
                    min={new Date().toISOString().split('T')[0]}
                    value={selectedDate}
                    onChange={(e) => handleDateSelect(e.target.value)}
                    className="text-xs font-medium border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                {/* Horizontal Quick Date Carousel */}
                <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 scrollbar-thin">
                  {dateOptions.map((opt) => {
                    const isSelected = selectedDate === opt.dateStr;
                    return (
                      <button
                        key={opt.dateStr}
                        onClick={() => handleDateSelect(opt.dateStr)}
                        className={`flex-1 min-w-[76px] py-3 px-2 rounded-2xl border text-center transition-all flex flex-col items-center justify-center cursor-pointer ${
                          isSelected
                            ? 'border-teal-600 bg-teal-600 text-white shadow-sm ring-2 ring-teal-600/30'
                            : opt.isSunday
                            ? 'border-slate-200 bg-slate-50/70 text-slate-400 opacity-60'
                            : 'border-slate-200 bg-white text-slate-700 hover:border-teal-300 hover:bg-slate-50'
                        }`}
                      >
                        <span className={`text-[11px] font-semibold ${isSelected ? 'text-teal-100' : 'text-slate-500'}`}>
                          {opt.dayName}
                        </span>
                        <span className="text-sm font-bold mt-0.5">{opt.formatted}</span>
                        {opt.isSunday && (
                          <span className="text-[9px] mt-0.5 text-slate-400">Closed</span>
                        )}
                      </button>
                    );
                  })}
                </div>

                <div className="text-xs text-slate-500 flex items-center justify-between">
                  <span>Selected Date: <strong className="text-slate-800">{formattedSelectedDate}</strong></span>
                  {slotsData.isOpen && (
                    <span className="text-teal-700 font-semibold">{slotsData.availableCount} Slots Available</span>
                  )}
                </div>
              </div>

              {/* Slots List or Closed State */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <label className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-teal-600" />
                  2. Select Consultation Time Slot
                </label>

                {slotsLoading ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-500">
                    <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
                    <span className="text-xs font-medium">Checking live schedule & available slots...</span>
                  </div>
                ) : !slotsData.isOpen ? (
                  <div className="p-6 rounded-2xl bg-amber-50/70 border border-amber-200 text-amber-900 text-center space-y-2">
                    <AlertCircle className="w-7 h-7 text-amber-600 mx-auto" />
                    <div className="font-bold text-sm">Chamber Closed on Selected Date</div>
                    <p className="text-xs text-amber-800 max-w-md mx-auto">
                      {slotsData.reason || 'The doctor is not taking consultations on this date. Please pick another date.'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Morning Shift */}
                    {morningSlots.length > 0 && (
                      <div className="space-y-2.5">
                        <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                          <span>Morning Shift (10:00 AM – 01:00 PM)</span>
                          <span className="text-[11px] text-slate-400 font-normal">
                            {morningSlots.filter((s) => s.available).length} open
                          </span>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                          {morningSlots.map((slot) => {
                            const isSelected = selectedSlot === slot.time;
                            return (
                              <button
                                key={slot.time}
                                disabled={!slot.available}
                                onClick={() => handleSlotSelect(slot.time, slot.available)}
                                className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all text-center flex flex-col items-center justify-center gap-0.5 ${
                                  !slot.available
                                    ? 'bg-slate-100/80 border-slate-200 text-slate-400 cursor-not-allowed line-through'
                                    : isSelected
                                    ? 'bg-teal-600 text-white border-teal-600 shadow-sm ring-2 ring-teal-500/20'
                                    : 'bg-white border-slate-200 text-slate-800 hover:border-teal-400 hover:bg-teal-50/40 cursor-pointer'
                                }`}
                              >
                                <span>{slot.time}</span>
                                <span className={`text-[10px] font-medium ${isSelected ? 'text-teal-100' : slot.available ? 'text-emerald-600' : 'text-slate-400'}`}>
                                  {slot.available ? 'Available' : 'Booked'}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Evening Shift */}
                    {eveningSlots.length > 0 && (
                      <div className="space-y-2.5">
                        <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                          <span>Evening Shift (05:00 PM – 08:00 PM)</span>
                          <span className="text-[11px] text-slate-400 font-normal">
                            {eveningSlots.filter((s) => s.available).length} open
                          </span>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                          {eveningSlots.map((slot) => {
                            const isSelected = selectedSlot === slot.time;
                            return (
                              <button
                                key={slot.time}
                                disabled={!slot.available}
                                onClick={() => handleSlotSelect(slot.time, slot.available)}
                                className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all text-center flex flex-col items-center justify-center gap-0.5 ${
                                  !slot.available
                                    ? 'bg-slate-100/80 border-slate-200 text-slate-400 cursor-not-allowed line-through'
                                    : isSelected
                                    ? 'bg-teal-600 text-white border-teal-600 shadow-sm ring-2 ring-teal-500/20'
                                    : 'bg-white border-slate-200 text-slate-800 hover:border-teal-400 hover:bg-teal-50/40 cursor-pointer'
                                }`}
                              >
                                <span>{slot.time}</span>
                                <span className={`text-[10px] font-medium ${isSelected ? 'text-teal-100' : slot.available ? 'text-emerald-600' : 'text-slate-400'}`}>
                                  {slot.available ? 'Available' : 'Booked'}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom Continue Action */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-100">
                <div className="text-xs text-slate-500">
                  {selectedSlot ? (
                    <span className="text-slate-900 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Selected: {formattedSelectedDate} at {selectedSlot}
                    </span>
                  ) : (
                    'Please click a time slot to continue.'
                  )}
                </div>

                <button
                  disabled={!selectedSlot || !slotsData.isOpen}
                  onClick={handleProceedToStep2}
                  className={`px-6 py-3 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
                    selectedSlot && slotsData.isOpen
                      ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-sm cursor-pointer'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span>Enter Patient Details</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

          {/* ================= STEP 2: PATIENT DETAILS ================= */}
          {step === 2 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              <div className="p-4 bg-teal-50/70 border border-teal-200 rounded-2xl flex items-center justify-between text-xs">
                <div>
                  <span className="text-teal-900 font-bold">Appointment Slot: </span>
                  <span className="text-slate-800 font-semibold">{formattedSelectedDate} · {selectedSlot}</span>
                </div>
                <button
                  onClick={() => setStep(1)}
                  className="text-teal-700 font-bold hover:underline cursor-pointer"
                >
                  Change Time
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Full Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-teal-600" />
                    Patient Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Sourav Mukherjee"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                {/* Mobile Number */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-teal-600" />
                    Mobile Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    placeholder="10-digit mobile (e.g. 9830112233)"
                    value={formData.patientPhone}
                    onChange={(e) => setFormData({ ...formData, patientPhone: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                  <span className="text-[10px] text-slate-500">Will receive WhatsApp/SMS confirmation</span>
                </div>

                {/* Age */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    Patient Age <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    placeholder="Age in years (e.g. 38)"
                    value={formData.patientAge}
                    onChange={(e) => setFormData({ ...formData, patientAge: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                {/* Gender */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    Gender <span className="text-rose-500">*</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Male', 'Female', 'Other'] as const).map((g) => (
                      <button
                        key={g}
                        type="button"
                        onClick={() => setFormData({ ...formData, patientGender: g })}
                        className={`py-2 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
                          formData.patientGender === g
                            ? 'bg-teal-600 text-white border-teal-600'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Email (Optional) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-teal-600" />
                    Email Address <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="email"
                    placeholder="name@example.com"
                    value={formData.patientEmail}
                    onChange={(e) => setFormData({ ...formData, patientEmail: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                {/* Address (Optional) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-teal-600" />
                    Residential Address <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Area, Locality or Landmark"
                    value={formData.patientAddress}
                    onChange={(e) => setFormData({ ...formData, patientAddress: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

              </div>

              {/* Reason for visit */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-teal-600" />
                  Primary Health Concern / Reason for Visit <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. Mild continuous fever for 3 days, throat pain, or routine blood pressure consultation"
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 resize-none"
                />
              </div>

              {/* Buttons */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back to Slots</span>
                </button>

                <button
                  type="button"
                  onClick={handleProceedToStep3}
                  className="px-6 py-3 rounded-xl text-sm font-bold bg-teal-600 text-white hover:bg-teal-700 shadow-sm flex items-center gap-2 cursor-pointer"
                >
                  <span>Review & Confirm</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

          {/* ================= STEP 3: PRE-CONFIRMATION SUMMARY REVIEW ================= */}
          {/* Per Requirement 3: Before final confirmation show:
              Doctor name, Appointment date, Appointment time, Consultation fee, Patient name, Mobile number */}
          {step === 3 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              <div className="text-center space-y-1 pb-2">
                <h3 className="text-xl font-bold text-slate-900">
                  Review Appointment Summary
                </h3>
                <p className="text-xs text-slate-500">
                  Please verify your details before generating the verified booking slip.
                </p>
              </div>

              {/* Summary Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm pb-4 border-b border-slate-200">
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Doctor</span>
                    <div className="text-base font-bold text-slate-900">{doctor.name}</div>
                    <div className="text-xs text-teal-700">{doctor.degrees} · {doctor.specialization}</div>
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Chamber Address</span>
                    <div className="text-sm font-bold text-slate-800">{clinic.clinicName}</div>
                    <div className="text-xs text-slate-600">{clinic.addressLine1}, {clinic.city}</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm pb-4 border-b border-slate-200">
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Appointment Date</span>
                    <div className="font-bold text-slate-900">{formattedSelectedDate}</div>
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Appointment Time</span>
                    <div className="font-bold text-teal-700">{selectedSlot}</div>
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Consultation Fee</span>
                    <div className="font-extrabold text-slate-900 tabular-nums">₹{doctor.consultationFee}</div>
                    <div className="text-[10px] text-slate-500">Payable at clinic desk</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Patient Name</span>
                    <div className="font-bold text-slate-900">{formData.patientName}</div>
                    <div className="text-xs text-slate-500">{formData.patientAge} Years · {formData.patientGender}</div>
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Contact Mobile</span>
                    <div className="font-bold text-slate-900 tabular-nums">{formData.patientPhone}</div>
                    {formData.patientEmail && (
                      <div className="text-xs text-slate-500">{formData.patientEmail}</div>
                    )}
                  </div>
                </div>

                <div className="pt-2 text-xs text-slate-600 bg-white p-3 rounded-xl border border-slate-200/80">
                  <span className="font-bold text-slate-700">Reason for Consultation: </span>
                  <span>{formData.reason}</span>
                </div>

              </div>

              {/* Booking Notice */}
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
                <span>
                  Immediate SMS & WhatsApp confirmation will be dispatched to your phone number upon confirmation.
                </span>
              </div>

              {/* Actions */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-100">
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => setStep(2)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Modify Details</span>
                </button>

                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={handleFinalBooking}
                  className="px-8 py-3.5 rounded-xl text-sm font-extrabold bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white shadow-md flex items-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Locking Slot & Confirming...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirm & Book Appointment</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </section>
  );
};
