import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Users,
  CheckCircle,
  XCircle,
  AlertTriangle,
  UserCheck,
  Search,
  Filter,
  Plus,
  RefreshCw,
  Edit,
  FileText,
  Settings,
  Bell,
  LogOut,
  CalendarDays,
  Activity,
  Send,
  Save,
  Check,
  ChevronDown,
  Lock,
  ArrowRight,
  Phone,
  Mail,
  User,
  Shield,
  MessageSquare,
} from 'lucide-react';
import {
  Appointment,
  Patient,
  DashboardStats,
  AvailabilitySettings,
  DoctorProfile,
  ClinicSettings,
  NotificationSettings,
  NotificationLog,
  AppointmentStatus,
} from '../../types/clinic';
import {
  getDashboardStats,
  getAdminAppointments,
  updateAppointment,
  createAdminAppointment,
  getAdminPatients,
  getAdminPatientDetail,
  getAdminAvailability,
  updateAdminAvailability,
  getAdminSettings,
  updateAdminSettings,
  changeAdminPassword,
  getAdminNotificationLogs,
  testNotification,
  clearStoredToken,
} from '../../services/api';

interface AdminDashboardProps {
  onLogout: () => void;
  onViewWebsite: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onLogout,
  onViewWebsite,
}) => {
  // Navigation tabs: 'dashboard' | 'appointments' | 'patients' | 'availability' | 'settings' | 'notifications'
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'appointments' | 'patients' | 'availability' | 'settings' | 'notifications'
  >('dashboard');

  // Loading & refresh states
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats | null>(null);

  // Appointments state & filters
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected appointment for details / edit notes modal
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [noteEdit, setNoteEdit] = useState('');
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleTime, setRescheduleTime] = useState('');
  const [isRescheduling, setIsRescheduling] = useState(false);

  // Patients state
  const [patients, setPatients] = useState<Patient[]>([]);
  const [patientSearch, setPatientSearch] = useState('');
  const [selectedPatientDetail, setSelectedPatientDetail] = useState<{
    patient: Patient;
    appointments: Appointment[];
  } | null>(null);

  // Availability settings state
  const [availability, setAvailability] = useState<AvailabilitySettings | null>(null);
  const [holidayDate, setHolidayDate] = useState('');
  const [holidayReason, setHolidayReason] = useState('');

  // Clinic & Doctor Settings state
  const [doctorSettings, setDoctorSettings] = useState<DoctorProfile | null>(null);
  const [clinicSettings, setClinicSettings] = useState<ClinicSettings | null>(null);
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings | null>(null);

  // Notification logs state
  const [notificationLogs, setNotificationLogs] = useState<NotificationLog[]>([]);
  const [testChannel, setTestChannel] = useState<'WHATSAPP' | 'SMS'>('WHATSAPP');
  const [testPhone, setTestPhone] = useState('');
  const [testResult, setTestResult] = useState<string | null>(null);

  // Password change state
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [passMessage, setPassMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New Walk-in appointment modal state
  const [showWalkinModal, setShowWalkinModal] = useState(false);
  const [walkinForm, setWalkinForm] = useState({
    patientName: '',
    patientPhone: '',
    patientEmail: '',
    patientAge: '35',
    patientGender: 'Male' as 'Male' | 'Female' | 'Other',
    appointmentDate: new Date().toISOString().split('T')[0],
    appointmentTime: '10:00 AM',
    reason: 'Walk-in Consultation',
    doctorNotes: '',
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Initial data loading
  const loadAllDashboardData = async () => {
    setLoading(true);
    try {
      const [statsData, aptsData, availData, settingsData, logsData, patientsData] =
        await Promise.all([
          getDashboardStats(),
          getAdminAppointments({ status: statusFilter, date: dateFilter, search: searchQuery }),
          getAdminAvailability(),
          getAdminSettings(),
          getAdminNotificationLogs(),
          getAdminPatients(),
        ]);

      setStats(statsData);
      setAppointments(aptsData.appointments);
      setAvailability(availData.availability);
      setDoctorSettings(settingsData.doctor);
      setClinicSettings(settingsData.clinic);
      setNotificationSettings(settingsData.notificationsConfig);
      setNotificationLogs(logsData.logs);
      setPatients(patientsData.patients);
    } catch (err: any) {
      console.error('Failed to load dashboard data:', err);
      if (err?.message?.includes('Session invalid') || err?.message?.includes('Authentication required')) {
        clearStoredToken();
        onLogout();
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllDashboardData();
  }, []);

  // Filter appointments when filter values change
  const handleFilterAppointments = async () => {
    try {
      const res = await getAdminAppointments({
        status: statusFilter,
        date: dateFilter,
        search: searchQuery,
      });
      setAppointments(res.appointments);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (!loading) {
      handleFilterAppointments();
    }
  }, [statusFilter, dateFilter, searchQuery]);

  // Appointment Status Updates
  const handleUpdateStatus = async (id: string, newStatus: AppointmentStatus) => {
    try {
      const res = await updateAppointment(id, { status: newStatus });
      if (res.success) {
        showToast(`Appointment status updated to ${newStatus}`);
        setAppointments((prev) =>
          prev.map((a) => (a.id === id ? { ...a, status: newStatus } : a))
        );
        if (selectedAppointment && selectedAppointment.id === id) {
          setSelectedAppointment({ ...selectedAppointment, status: newStatus });
        }
        // Refresh stats
        getDashboardStats().then(setStats).catch(console.error);
      }
    } catch (err: any) {
      alert(err?.message || 'Failed to update status');
    }
  };

  // Save Doctor Clinical Notes
  const handleSaveNotes = async () => {
    if (!selectedAppointment) return;
    try {
      const res = await updateAppointment(selectedAppointment.id, { doctorNotes: noteEdit });
      if (res.success) {
        showToast('Clinical notes saved successfully.');
        setSelectedAppointment({ ...selectedAppointment, doctorNotes: noteEdit });
        setAppointments((prev) =>
          prev.map((a) =>
            a.id === selectedAppointment.id ? { ...a, doctorNotes: noteEdit } : a
          )
        );
      }
    } catch (err: any) {
      alert(err.message || 'Failed to save notes');
    }
  };

  // Reschedule appointment
  const handleReschedule = async () => {
    if (!selectedAppointment || !rescheduleDate || !rescheduleTime) {
      alert('Please select both a new date and time slot.');
      return;
    }
    try {
      const res = await updateAppointment(selectedAppointment.id, {
        appointmentDate: rescheduleDate,
        appointmentTime: rescheduleTime,
      });
      if (res.success) {
        showToast('Appointment rescheduled successfully.');
        setIsRescheduling(false);
        setSelectedAppointment(res.appointment);
        setAppointments((prev) =>
          prev.map((a) => (a.id === selectedAppointment.id ? res.appointment : a))
        );
      }
    } catch (err: any) {
      alert(err.message || 'Reschedule conflict: slot already booked.');
    }
  };

  // Create Walk-in appointment
  const handleCreateWalkin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await createAdminAppointment(walkinForm);
      if (res.success) {
        showToast(`Appointment created: ${res.appointment.appointmentId}`);
        setShowWalkinModal(false);
        setAppointments([res.appointment, ...appointments]);
        getDashboardStats().then(setStats).catch(console.error);
      }
    } catch (err: any) {
      alert(err.message || 'Failed to create appointment');
    }
  };

  // View patient profile
  const handleOpenPatient = async (patientId: string) => {
    try {
      const data = await getAdminPatientDetail(patientId);
      setSelectedPatientDetail(data);
    } catch (err) {
      console.error(err);
    }
  };

  // Save Availability settings
  const handleSaveAvailability = async () => {
    if (!availability) return;
    try {
      const res = await updateAdminAvailability(availability);
      if (res.success) {
        showToast('Availability & slot schedule saved successfully.');
      }
    } catch (err: any) {
      alert(err.message || 'Failed to save availability');
    }
  };

  // Save Settings
  const handleSaveSettings = async () => {
    if (!doctorSettings || !clinicSettings || !notificationSettings) return;
    try {
      const res = await updateAdminSettings({
        doctor: doctorSettings,
        clinic: clinicSettings,
        notificationsConfig: notificationSettings,
      });
      if (res.success) {
        showToast('Doctor & Clinic Settings updated successfully.');
      }
    } catch (err: any) {
      alert(err.message || 'Failed to update settings');
    }
  };

  // Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMessage(null);
    try {
      const res = await changeAdminPassword(currentPass, newPass);
      if (res.success) {
        setPassMessage({ type: 'success', text: 'Password successfully changed!' });
        setCurrentPass('');
        setNewPass('');
      }
    } catch (err: any) {
      setPassMessage({ type: 'error', text: err.message || 'Failed to change password' });
    }
  };

  // Send Test Notification
  const handleSendTestNotification = async () => {
    setTestResult(null);
    try {
      const res = await testNotification(testChannel, testPhone || undefined);
      setTestResult(res.message);
      // Reload logs
      getAdminNotificationLogs().then((d) => setNotificationLogs(d.logs));
    } catch (err: any) {
      setTestResult(`Error: ${err.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans antialiased text-slate-900">
      
      {/* Toast message banner */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-teal-800 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2 text-sm font-semibold animate-in slide-in-from-top-3">
          <Check className="w-4 h-4 text-teal-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ADMIN TOP BAR */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold">
                JD
              </div>
              <div>
                <h1 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  Dr. Jagadish Das, MBBS
                </h1>
                <span className="text-[11px] text-teal-400 font-medium">
                  Doctor Clinical Admin Portal
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-4">
              <button
                onClick={onViewWebsite}
                className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                View Public Site
              </button>

              <button
                onClick={() => setShowWalkinModal(true)}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">+ New Walk-in</span>
              </button>

              <button
                onClick={() => {
                  clearStoredToken();
                  onLogout();
                }}
                className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

        {/* Sub-Nav Tabs Bar */}
        <div className="bg-slate-800/90 border-t border-slate-700/50 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 scrollbar-none text-xs font-medium text-slate-300">
            {[
              { id: 'dashboard', label: "Today's Overview", icon: Activity },
              { id: 'appointments', label: 'All Appointments', icon: Calendar },
              { id: 'patients', label: 'Patients Directory', icon: Users },
              { id: 'availability', label: 'Manage Availability', icon: Clock },
              { id: 'notifications', label: 'Notification Logs', icon: Bell },
              { id: 'settings', label: 'Clinic Settings', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-2 rounded-lg flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-teal-600 text-white font-bold shadow-xs'
                      : 'hover:bg-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* ================= TAB 1: OVERVIEW & ANALYTICS ================= */}
        {activeTab === 'dashboard' && stats && (
          <div className="space-y-8 animate-in fade-in duration-150">
            
            {/* Quick Action Shortcuts */}
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Clinic Consultation Dashboard
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Real-time patient bookings, attendance breakdown, and daily schedule.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setDateFilter(new Date().toISOString().split('T')[0]);
                    setActiveTab('appointments');
                  }}
                  className="px-3.5 py-2 text-xs font-bold text-teal-800 bg-teal-100 hover:bg-teal-200 rounded-xl transition-colors cursor-pointer"
                >
                  View Today's Appointments
                </button>
                <button
                  onClick={() => setShowWalkinModal(true)}
                  className="px-3.5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Walk-in</span>
                </button>
                <button
                  onClick={loadAllDashboardData}
                  className="p-2 text-slate-600 hover:text-slate-900 hover:bg-white rounded-xl border border-slate-200 transition-colors"
                  title="Refresh Data"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* 8 DASHBOARD METRIC CARDS (Per Section 6) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              
              {/* Today's Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Today's Total</span>
                  <Calendar className="w-4 h-4 text-teal-600" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                    {stats.todayAppointmentsCount}
                  </div>
                  <div className="text-[11px] text-teal-700 font-medium mt-0.5">
                    {stats.todayPatientCount} unique patients today
                  </div>
                </div>
              </div>

              {/* Upcoming Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Upcoming</span>
                  <Clock className="w-4 h-4 text-blue-600" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                    {stats.upcomingAppointmentsCount}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Scheduled future visits
                  </div>
                </div>
              </div>

              {/* Confirmed Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Confirmed</span>
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 tabular-nums">
                    {stats.confirmedCount}
                  </div>
                  <div className="text-[11px] text-emerald-600 mt-0.5">
                    Slot locked & verified
                  </div>
                </div>
              </div>

              {/* Pending Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Pending</span>
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-amber-600 tabular-nums">
                    {stats.pendingCount}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Awaiting clinical review
                  </div>
                </div>
              </div>

              {/* Completed Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Completed</span>
                  <UserCheck className="w-4 h-4 text-teal-600" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                    {stats.completedCount}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Consultations finished
                  </div>
                </div>
              </div>

              {/* Cancelled Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Cancelled</span>
                  <XCircle className="w-4 h-4 text-rose-500" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-rose-700 tabular-nums">
                    {stats.cancelledCount}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Released time slots
                  </div>
                </div>
              </div>

              {/* No-Show Appointments */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">No-Show</span>
                  <Users className="w-4 h-4 text-slate-400" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-slate-700 tabular-nums">
                    {stats.noShowCount}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Patient missed visit
                  </div>
                </div>
              </div>

              {/* Total Registered Patients */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500">
                  <span className="text-xs font-semibold uppercase tracking-wider">Total Patients</span>
                  <Users className="w-4 h-4 text-teal-600" />
                </div>
                <div className="mt-2">
                  <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                    {stats.totalPatientsCount}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Patient medical profiles
                  </div>
                </div>
              </div>

            </div>

            {/* Visual Analytics Chart: 7-Day Appointment Trend */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      7-Day Appointment Booking Volume
                    </h3>
                    <p className="text-xs text-slate-500">
                      Daily patient consultation loads
                    </p>
                  </div>
                  <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg">
                    Weekly Trend
                  </span>
                </div>

                {/* Bar chart representation */}
                <div className="h-52 flex items-end justify-between gap-3 pt-6 pb-2 px-2 border-b border-slate-100">
                  {stats.past7Days.map((item, idx) => {
                    const maxCount = Math.max(...stats.past7Days.map((d) => d.count), 6);
                    const heightPercent = Math.max((item.count / maxCount) * 100, 10);
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                        <span className="text-xs font-extrabold text-slate-700 tabular-nums">
                          {item.count}
                        </span>
                        <div className="w-full bg-slate-100 rounded-t-xl overflow-hidden h-36 flex items-end">
                          <div
                            style={{ height: `${heightPercent}%` }}
                            className="w-full bg-gradient-to-t from-teal-700 to-teal-500 rounded-t-lg transition-all group-hover:from-teal-800 group-hover:to-teal-400"
                          />
                        </div>
                        <span className="text-[10px] sm:text-xs font-semibold text-slate-500 truncate w-full text-center">
                          {item.label.split(',')[0]}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status Distribution */}
              <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Status Breakdown
                  </h3>
                  <p className="text-xs text-slate-500">
                    All-time appointment state distribution
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  {[
                    { label: 'Confirmed', count: stats.confirmedCount, color: 'bg-emerald-500' },
                    { label: 'Completed', count: stats.completedCount, color: 'bg-teal-600' },
                    { label: 'Pending', count: stats.pendingCount, color: 'bg-amber-500' },
                    { label: 'Cancelled', count: stats.cancelledCount, color: 'bg-rose-500' },
                    { label: 'No-Show', count: stats.noShowCount, color: 'bg-slate-400' },
                  ].map((s) => (
                    <div key={s.label} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-700">{s.label}</span>
                        <span className="font-bold text-slate-900 tabular-nums">{s.count}</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${s.color}`}
                          style={{
                            width: `${stats.totalAppointmentsCount > 0 ? (s.count / stats.totalAppointmentsCount) * 100 : 0}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Quick Appointments Preview */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Recent Appointments</h3>
                  <p className="text-xs text-slate-500">Latest patient booking requests</p>
                </div>
                <button
                  onClick={() => setActiveTab('appointments')}
                  className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1 cursor-pointer"
                >
                  <span>Open Full Manager</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">ID</th>
                      <th className="py-2.5 px-3">Patient</th>
                      <th className="py-2.5 px-3">Phone</th>
                      <th className="py-2.5 px-3">Date & Time</th>
                      <th className="py-2.5 px-3">Reason</th>
                      <th className="py-2.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {appointments.slice(0, 5).map((apt) => (
                      <tr key={apt.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-3 font-mono font-bold text-teal-800">
                          {apt.appointmentId}
                        </td>
                        <td className="py-3 px-3 font-bold text-slate-900">
                          {apt.patientName} ({apt.patientAge}y)
                        </td>
                        <td className="py-3 px-3 tabular-nums text-slate-600">
                          {apt.patientPhone}
                        </td>
                        <td className="py-3 px-3 text-slate-700">
                          {apt.appointmentDate} · <span className="font-semibold">{apt.appointmentTime}</span>
                        </td>
                        <td className="py-3 px-3 text-slate-600 max-w-xs truncate">
                          {apt.reason}
                        </td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                              apt.status === 'CONFIRMED'
                                ? 'bg-emerald-100 text-emerald-800'
                                : apt.status === 'COMPLETED'
                                ? 'bg-teal-100 text-teal-800'
                                : apt.status === 'CANCELLED'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {apt.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================= TAB 2: APPOINTMENT MANAGEMENT ================= */}
        {activeTab === 'appointments' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Appointment Management
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Search, filter, update statuses, reschedule, and write doctor clinical notes.
                </p>
              </div>

              <button
                onClick={() => setShowWalkinModal(true)}
                className="px-4 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Walk-in Patient</span>
              </button>
            </div>

            {/* Filter Toolbar */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center gap-3">
              {/* Search */}
              <div className="flex-1 min-w-[220px] relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by Patient name, phone, or APT-ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-slate-500 font-semibold">Status:</span>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-2.5 py-2 text-xs border border-slate-300 rounded-xl bg-white font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="CONFIRMED">CONFIRMED</option>
                  <option value="PENDING">PENDING</option>
                  <option value="COMPLETED">COMPLETED</option>
                  <option value="CANCELLED">CANCELLED</option>
                  <option value="NO-SHOW">NO-SHOW</option>
                </select>
              </div>

              {/* Date Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-slate-500 font-semibold">Date:</span>
                <input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl bg-white font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
                {dateFilter && (
                  <button
                    onClick={() => setDateFilter('')}
                    className="text-xs text-rose-600 hover:underline"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Quick Today Filter */}
              <button
                onClick={() => setDateFilter(new Date().toISOString().split('T')[0])}
                className="px-3 py-2 text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-xl transition-colors cursor-pointer"
              >
                Today Only
              </button>
            </div>

            {/* Clean Table per Section 7 */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Appointment ID</th>
                      <th className="py-3 px-4">Patient</th>
                      <th className="py-3 px-4">Phone</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Time</th>
                      <th className="py-3 px-4">Reason</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {appointments.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-12 text-center text-slate-400">
                          No appointments found matching current filters.
                        </td>
                      </tr>
                    ) : (
                      appointments.map((apt) => (
                        <tr key={apt.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-teal-800">
                            {apt.appointmentId}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{apt.patientName}</div>
                            <div className="text-[11px] text-slate-500">
                              {apt.patientAge}y · {apt.patientGender}
                            </div>
                          </td>
                          <td className="py-3 px-4 tabular-nums text-slate-700">
                            {apt.patientPhone}
                          </td>
                          <td className="py-3 px-4 text-slate-800 font-medium">
                            {apt.appointmentDate}
                          </td>
                          <td className="py-3 px-4 font-bold text-teal-900">
                            {apt.appointmentTime}
                          </td>
                          <td className="py-3 px-4 text-slate-600 max-w-xs truncate" title={apt.reason}>
                            {apt.reason}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                apt.status === 'CONFIRMED'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : apt.status === 'COMPLETED'
                                  ? 'bg-teal-100 text-teal-800'
                                  : apt.status === 'CANCELLED'
                                  ? 'bg-rose-100 text-rose-800'
                                  : apt.status === 'NO-SHOW'
                                  ? 'bg-slate-200 text-slate-700'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {apt.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Open Details / Notes Modal */}
                              <button
                                onClick={() => {
                                  setSelectedAppointment(apt);
                                  setNoteEdit(apt.doctorNotes || '');
                                  setRescheduleDate(apt.appointmentDate);
                                  setRescheduleTime(apt.appointmentTime);
                                  setIsRescheduling(false);
                                }}
                                className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-teal-800 hover:bg-teal-50 rounded-lg transition-colors cursor-pointer"
                                title="Clinical Details & Notes"
                              >
                                Details & Notes
                              </button>

                              {/* Quick Mark Completed */}
                              {apt.status !== 'COMPLETED' && apt.status !== 'CANCELLED' && (
                                <button
                                  onClick={() => handleUpdateStatus(apt.id, 'COMPLETED')}
                                  className="px-2 py-1 text-[11px] font-bold text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors cursor-pointer"
                                  title="Mark as Completed"
                                >
                                  Complete
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================= TAB 3: PATIENT PROFILES ================= */}
        {activeTab === 'patients' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Patient Medical Profiles
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Secure directory of patient records, visit histories, and physician clinical notes.
                </p>
              </div>

              <div className="w-full sm:w-72 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search patient name, phone, or email..."
                  value={patientSearch}
                  onChange={(e) => {
                    setPatientSearch(e.target.value);
                    getAdminPatients(e.target.value).then((d) => setPatients(d.patients));
                  }}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {patients.map((pat) => (
                <div
                  key={pat.id}
                  onClick={() => handleOpenPatient(pat.id)}
                  className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-teal-400 hover:shadow-md transition-all cursor-pointer space-y-3 group"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm group-hover:text-teal-700 transition-colors">
                        {pat.name}
                      </h3>
                      <div className="text-xs text-slate-500">
                        {pat.age} Years · {pat.gender}
                      </div>
                    </div>
                    <span className="text-xs font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md">
                      {pat.totalAppointments} Visits
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1 pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-1.5 tabular-nums">
                      <Phone className="w-3.5 h-3.5 text-slate-400" /> {pat.phone}
                    </div>
                    {pat.address && (
                      <div className="flex items-center gap-1.5 truncate">
                        <User className="w-3.5 h-3.5 text-slate-400" /> {pat.address}
                      </div>
                    )}
                  </div>

                  {pat.notes && (
                    <p className="text-[11px] text-slate-500 line-clamp-2 bg-slate-50 p-2 rounded-lg italic">
                      "{pat.notes}"
                    </p>
                  )}
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ================= TAB 4: AVAILABILITY & SLOT MANAGEMENT ================= */}
        {activeTab === 'availability' && availability && (
          <div className="space-y-6 animate-in fade-in duration-150">
            
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Consultation Availability & Slot Configuration
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Configure working days, consultation shift hours, slot duration, and public holidays.
                </p>
              </div>

              <button
                onClick={handleSaveAvailability}
                className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Save className="w-4 h-4" />
                <span>Save Schedule</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Working Days & Capacity */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-teal-600" />
                  Working Days & Capacity
                </h3>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-800">
                    Active Clinic Consultation Days
                  </label>
                  <div className="grid grid-cols-7 gap-1.5">
                    {[
                      { num: 1, label: 'Mon' },
                      { num: 2, label: 'Tue' },
                      { num: 3, label: 'Wed' },
                      { num: 4, label: 'Thu' },
                      { num: 5, label: 'Fri' },
                      { num: 6, label: 'Sat' },
                      { num: 0, label: 'Sun' },
                    ].map((d) => {
                      const isWorking = availability.workingDays.includes(d.num);
                      return (
                        <button
                          key={d.num}
                          type="button"
                          onClick={() => {
                            const current = [...availability.workingDays];
                            const updated = isWorking
                              ? current.filter((x) => x !== d.num)
                              : [...current, d.num];
                            setAvailability({ ...availability, workingDays: updated });
                          }}
                          className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                            isWorking
                              ? 'bg-teal-600 text-white border-teal-600'
                              : 'bg-slate-50 text-slate-400 border-slate-200'
                          }`}
                        >
                          {d.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      Slot Duration (Minutes)
                    </label>
                    <select
                      value={availability.slotDurationMinutes}
                      onChange={(e) =>
                        setAvailability({
                          ...availability,
                          slotDurationMinutes: parseInt(e.target.value, 10),
                        })
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                    >
                      <option value="15">15 Minutes (Default)</option>
                      <option value="20">20 Minutes</option>
                      <option value="30">30 Minutes</option>
                      <option value="45">45 Minutes</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      Max Appointments / Day
                    </label>
                    <input
                      type="number"
                      value={availability.maxAppointmentsPerDay}
                      onChange={(e) =>
                        setAvailability({
                          ...availability,
                          maxAppointmentsPerDay: parseInt(e.target.value, 10),
                        })
                      }
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>
              </div>

              {/* Shifts: Morning & Evening */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-teal-600" />
                  Shift Timing Boundaries
                </h3>

                {/* Morning Shift */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">Morning Shift</span>
                    <input
                      type="checkbox"
                      checked={availability.morningShift.enabled}
                      onChange={(e) =>
                        setAvailability({
                          ...availability,
                          morningShift: {
                            ...availability.morningShift,
                            enabled: e.target.checked,
                          },
                        })
                      }
                      className="w-4 h-4 text-teal-600 rounded"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[11px] text-slate-500">Start Time (24h)</span>
                      <input
                        type="time"
                        value={availability.morningShift.startTime}
                        onChange={(e) =>
                          setAvailability({
                            ...availability,
                            morningShift: {
                              ...availability.morningShift,
                              startTime: e.target.value,
                            },
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-500">End Time (24h)</span>
                      <input
                        type="time"
                        value={availability.morningShift.endTime}
                        onChange={(e) =>
                          setAvailability({
                            ...availability,
                            morningShift: {
                              ...availability.morningShift,
                              endTime: e.target.value,
                            },
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Evening Shift */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">Evening Shift</span>
                    <input
                      type="checkbox"
                      checked={availability.eveningShift.enabled}
                      onChange={(e) =>
                        setAvailability({
                          ...availability,
                          eveningShift: {
                            ...availability.eveningShift,
                            enabled: e.target.checked,
                          },
                        })
                      }
                      className="w-4 h-4 text-teal-600 rounded"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[11px] text-slate-500">Start Time (24h)</span>
                      <input
                        type="time"
                        value={availability.eveningShift.startTime}
                        onChange={(e) =>
                          setAvailability({
                            ...availability,
                            eveningShift: {
                              ...availability.eveningShift,
                              startTime: e.target.value,
                            },
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-500">End Time (24h)</span>
                      <input
                        type="time"
                        value={availability.eveningShift.endTime}
                        onChange={(e) =>
                          setAvailability({
                            ...availability,
                            eveningShift: {
                              ...availability.eveningShift,
                              endTime: e.target.value,
                            },
                          })
                        }
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Holidays & Special Unavailable Dates */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-bold text-slate-900">
                Clinic Holidays & Closed Dates
              </h3>

              <div className="flex flex-wrap items-center gap-3">
                <input
                  type="date"
                  value={holidayDate}
                  onChange={(e) => setHolidayDate(e.target.value)}
                  className="px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
                <input
                  type="text"
                  placeholder="Reason (e.g. National Holiday / Doctor Leave)"
                  value={holidayReason}
                  onChange={(e) => setHolidayReason(e.target.value)}
                  className="flex-1 min-w-[200px] px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!holidayDate || !holidayReason) return;
                    setAvailability({
                      ...availability,
                      holidays: [...availability.holidays, { date: holidayDate, reason: holidayReason }],
                    });
                    setHolidayDate('');
                    setHolidayReason('');
                  }}
                  className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl cursor-pointer"
                >
                  + Add Holiday
                </button>
              </div>

              <div className="space-y-2 pt-2">
                {availability.holidays.map((h, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900">{h.date}</span> —{' '}
                      <span className="text-slate-600">{h.reason}</span>
                    </div>
                    <button
                      onClick={() =>
                        setAvailability({
                          ...availability,
                          holidays: availability.holidays.filter((_, idx) => idx !== i),
                        })
                      }
                      className="text-rose-600 font-bold hover:underline"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ================= TAB 5: NOTIFICATION LOGS ================= */}
        {activeTab === 'notifications' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  SMS & WhatsApp Notification History
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Real-time dispatch telemetry, message logs, and automatic SMS fallback tracker.
                </p>
              </div>

              <button
                onClick={() => getAdminNotificationLogs().then((d) => setNotificationLogs(d.logs))}
                className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Logs</span>
              </button>
            </div>

            {/* Test Notification Dispatch Tool */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800">
                Test Notification Gateway
              </h3>
              <div className="flex flex-wrap items-center gap-3">
                <select
                  value={testChannel}
                  onChange={(e) => setTestChannel(e.target.value as any)}
                  className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white font-medium"
                >
                  <option value="WHATSAPP">WhatsApp Business API</option>
                  <option value="SMS">SMS Gateway</option>
                </select>

                <input
                  type="tel"
                  placeholder="Recipient Mobile (Leave empty for Doctor Phone)"
                  value={testPhone}
                  onChange={(e) => setTestPhone(e.target.value)}
                  className="flex-1 min-w-[220px] px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />

                <button
                  onClick={handleSendTestNotification}
                  className="px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Test Notification</span>
                </button>
              </div>

              {testResult && (
                <div className="text-xs font-semibold text-teal-800 bg-teal-50 p-2.5 rounded-lg border border-teal-200">
                  {testResult}
                </div>
              )}
            </div>

            {/* Notification Logs Table per Section 17 */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Channel</th>
                      <th className="py-3 px-4">Recipient</th>
                      <th className="py-3 px-4">Appointment ID</th>
                      <th className="py-3 px-4">Timestamp</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Message Snippet</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {notificationLogs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-400">
                          No notification dispatches logged yet.
                        </td>
                      </tr>
                    ) : (
                      notificationLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/80">
                          <td className="py-3 px-4 font-bold">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                log.channel === 'WHATSAPP'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {log.channel}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-800">{log.recipientType}</div>
                            <div className="text-[11px] text-slate-500 tabular-nums">{log.recipientPhone}</div>
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-teal-800">
                            {log.appointmentId}
                          </td>
                          <td className="py-3 px-4 text-slate-500">
                            {new Date(log.sentAt).toLocaleString()}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                log.status === 'SENT'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : log.status === 'FALLBACK_SENT'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {log.status === 'FALLBACK_SENT' ? 'Fallback SMS Sent' : log.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-600 max-w-sm truncate" title={log.message}>
                            {log.message}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================= TAB 6: CLINIC & DOCTOR SETTINGS ================= */}
        {activeTab === 'settings' && doctorSettings && clinicSettings && notificationSettings && (
          <div className="space-y-6 animate-in fade-in duration-150">
            
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Clinic & Doctor Settings
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  Update doctor details, consultation fees, chamber address, API keys, and security credentials.
                </p>
              </div>

              <button
                onClick={handleSaveSettings}
                className="px-6 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Save className="w-4 h-4" />
                <span>Save All Settings</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Doctor Profile Settings */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-4 h-4 text-teal-600" />
                  Doctor Professional Profile
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-800 block mb-1">Doctor Full Name</label>
                    <input
                      type="text"
                      value={doctorSettings.name}
                      onChange={(e) => setDoctorSettings({ ...doctorSettings, name: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">Degrees & Qualifications</label>
                      <input
                        type="text"
                        value={doctorSettings.degrees}
                        onChange={(e) => setDoctorSettings({ ...doctorSettings, degrees: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">Registration Number</label>
                      <input
                        type="text"
                        value={doctorSettings.registrationNumber}
                        onChange={(e) =>
                          setDoctorSettings({ ...doctorSettings, registrationNumber: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">Years of Experience</label>
                      <input
                        type="number"
                        value={doctorSettings.experienceYears}
                        onChange={(e) =>
                          setDoctorSettings({
                            ...doctorSettings,
                            experienceYears: parseInt(e.target.value, 10),
                          })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">Consultation Fee (₹)</label>
                      <input
                        type="number"
                        value={doctorSettings.consultationFee}
                        onChange={(e) =>
                          setDoctorSettings({
                            ...doctorSettings,
                            consultationFee: parseInt(e.target.value, 10),
                          })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-slate-800 block mb-1">Medical Specialization</label>
                    <input
                      type="text"
                      value={doctorSettings.specialization}
                      onChange={(e) =>
                        setDoctorSettings({ ...doctorSettings, specialization: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-800 block mb-1">About Doctor Bio</label>
                    <textarea
                      rows={3}
                      value={doctorSettings.about}
                      onChange={(e) => setDoctorSettings({ ...doctorSettings, about: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* Clinic Chamber Information */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-teal-600" />
                  Clinic Chamber Information
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-800 block mb-1">Clinic Name</label>
                    <input
                      type="text"
                      value={clinicSettings.clinicName}
                      onChange={(e) => setClinicSettings({ ...clinicSettings, clinicName: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-800 block mb-1">Address Line 1</label>
                    <input
                      type="text"
                      value={clinicSettings.addressLine1}
                      onChange={(e) =>
                        setClinicSettings({ ...clinicSettings, addressLine1: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">City / District</label>
                      <input
                        type="text"
                        value={clinicSettings.city}
                        onChange={(e) => setClinicSettings({ ...clinicSettings, city: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">PIN Code</label>
                      <input
                        type="text"
                        value={clinicSettings.pincode}
                        onChange={(e) =>
                          setClinicSettings({ ...clinicSettings, pincode: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">Primary Phone</label>
                      <input
                        type="text"
                        value={clinicSettings.phonePrimary}
                        onChange={(e) =>
                          setClinicSettings({ ...clinicSettings, phonePrimary: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-800 block mb-1">Emergency Phone</label>
                      <input
                        type="text"
                        value={clinicSettings.phoneEmergency}
                        onChange={(e) =>
                          setClinicSettings({ ...clinicSettings, phoneEmergency: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-slate-800 block mb-1">Parking & Accessibility Info</label>
                    <input
                      type="text"
                      value={clinicSettings.parkingInfo}
                      onChange={(e) =>
                        setClinicSettings({ ...clinicSettings, parkingInfo: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>
              </div>

              {/* Notification Gateway Config */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-teal-600" />
                  WhatsApp & SMS Configuration
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                    <span className="font-bold text-slate-800">WhatsApp Notification API</span>
                    <input
                      type="checkbox"
                      checked={notificationSettings.whatsappEnabled}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          whatsappEnabled: e.target.checked,
                        })
                      }
                      className="w-4 h-4 text-teal-600 rounded"
                    />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                    <span className="font-bold text-slate-800">SMS Fallback Channel</span>
                    <input
                      type="checkbox"
                      checked={notificationSettings.smsFallbackEnabled}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          smsFallbackEnabled: e.target.checked,
                        })
                      }
                      className="w-4 h-4 text-teal-600 rounded"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-800 block mb-1">
                      Doctor Notification Phone (Receives new booking alerts)
                    </label>
                    <input
                      type="text"
                      value={notificationSettings.doctorNotificationPhone}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          doctorNotificationPhone: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>
              </div>

              {/* Admin Password Change Form */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-teal-600" />
                  Security: Change Admin Password
                </h3>

                <form onSubmit={handleChangePassword} className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-slate-800 block mb-1">Current Password</label>
                    <input
                      type="password"
                      value={currentPass}
                      onChange={(e) => setCurrentPass(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      required
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-800 block mb-1">New Password (min 8 chars)</label>
                    <input
                      type="password"
                      value={newPass}
                      onChange={(e) => setNewPass(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                      required
                    />
                  </div>

                  {passMessage && (
                    <div
                      className={`p-2.5 rounded-lg text-xs font-semibold ${
                        passMessage.type === 'success'
                          ? 'bg-emerald-50 text-emerald-800'
                          : 'bg-rose-50 text-rose-800'
                      }`}
                    >
                      {passMessage.text}
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                  >
                    Update Password
                  </button>
                </form>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* ================= MODAL: APPOINTMENT DETAILS & NOTES ================= */}
      {selectedAppointment && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">{selectedAppointment.appointmentId}</h3>
                <p className="text-xs text-slate-400">Clinical Consultation Record</p>
              </div>
              <button
                onClick={() => setSelectedAppointment(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-5 text-xs sm:text-sm">
              
              <div className="grid grid-cols-2 gap-4 pb-4 border-b border-slate-100">
                <div>
                  <span className="text-slate-500 text-xs">Patient</span>
                  <div className="font-bold text-slate-900">{selectedAppointment.patientName}</div>
                  <div className="text-xs text-slate-500">
                    {selectedAppointment.patientAge} Years · {selectedAppointment.patientGender}
                  </div>
                  <div className="text-xs text-slate-700 font-mono mt-0.5">
                    {selectedAppointment.patientPhone}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 text-xs">Schedule</span>
                  <div className="font-bold text-slate-900">{selectedAppointment.appointmentDate}</div>
                  <div className="text-teal-700 font-bold">{selectedAppointment.appointmentTime}</div>
                  <div className="text-xs text-slate-500">Fee: ₹{selectedAppointment.consultationFee}</div>
                </div>
              </div>

              <div>
                <span className="text-slate-500 text-xs">Reason for Visit</span>
                <p className="text-slate-800 font-medium mt-0.5 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {selectedAppointment.reason}
                </p>
              </div>

              {/* Status Update Buttons */}
              <div className="space-y-1.5">
                <span className="text-slate-500 text-xs font-semibold">Change Appointment Status</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {(['CONFIRMED', 'COMPLETED', 'PENDING', 'CANCELLED', 'NO-SHOW'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => handleUpdateStatus(selectedAppointment.id, st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        selectedAppointment.status === st
                          ? 'bg-teal-700 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reschedule Section */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsRescheduling(!isRescheduling)}
                  className="text-xs font-bold text-teal-700 hover:underline flex items-center gap-1"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>{isRescheduling ? 'Cancel Reschedule' : 'Reschedule Date & Time'}</span>
                </button>

                {isRescheduling && (
                  <div className="mt-2 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="date"
                        value={rescheduleDate}
                        onChange={(e) => setRescheduleDate(e.target.value)}
                        className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                      <input
                        type="text"
                        placeholder="Time (e.g. 11:30 AM)"
                        value={rescheduleTime}
                        onChange={(e) => setRescheduleTime(e.target.value)}
                        className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                    <button
                      onClick={handleReschedule}
                      className="w-full py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                    >
                      Confirm Reschedule
                    </button>
                  </div>
                )}
              </div>

              {/* Doctor Clinical Notes */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-slate-700 font-bold text-xs flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-teal-600" />
                    Doctor Clinical Notes
                  </span>
                  <button
                    onClick={handleSaveNotes}
                    className="text-xs font-bold text-teal-700 hover:text-teal-900 cursor-pointer"
                  >
                    Save Notes
                  </button>
                </div>
                <textarea
                  rows={3}
                  placeholder="Record blood pressure, diagnosis, prescriptions, or follow-up instructions..."
                  value={noteEdit}
                  onChange={(e) => setNoteEdit(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600 resize-none"
                />
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setSelectedAppointment(null)}
                  className="w-full py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
                >
                  Close Window
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ================= MODAL: PATIENT HISTORY ================= */}
      {selectedPatientDetail && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="bg-teal-800 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">{selectedPatientDetail.patient.name}</h3>
                <p className="text-xs text-teal-200">Patient Medical History</p>
              </div>
              <button
                onClick={() => setSelectedPatientDetail(null)}
                className="p-1 text-teal-200 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 gap-4 pb-3 border-b border-slate-100">
                <div>
                  <span className="text-slate-500 text-xs">Contact</span>
                  <div className="font-bold text-slate-900 tabular-nums">
                    {selectedPatientDetail.patient.phone}
                  </div>
                  <div className="text-slate-500 text-xs">
                    {selectedPatientDetail.patient.email || 'No email registered'}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500 text-xs">Demographics</span>
                  <div className="font-bold text-slate-900">
                    {selectedPatientDetail.patient.age}y · {selectedPatientDetail.patient.gender}
                  </div>
                  <div className="text-slate-500 text-xs">
                    First Visit: {selectedPatientDetail.patient.firstVisitDate}
                  </div>
                </div>
              </div>

              <div>
                <span className="text-slate-800 font-bold text-xs">Past Consultation Visits</span>
                <div className="mt-2 space-y-2 max-h-60 overflow-y-auto pr-1">
                  {selectedPatientDetail.appointments.map((a) => (
                    <div key={a.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-teal-800">{a.appointmentId}</span>
                        <span className="font-semibold text-slate-700">
                          {a.appointmentDate} at {a.appointmentTime}
                        </span>
                        <span className="font-bold text-[11px] px-2 py-0.5 rounded bg-slate-200 text-slate-800">
                          {a.status}
                        </span>
                      </div>
                      <div className="text-slate-600 text-xs">Reason: {a.reason}</div>
                      {a.doctorNotes && (
                        <div className="text-xs text-teal-900 bg-teal-50 p-2 rounded-lg mt-1">
                          <strong>Doctor Notes: </strong>{a.doctorNotes}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setSelectedPatientDetail(null)}
                  className="w-full py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
                >
                  Close Record
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE WALK-IN / OFFLINE APPOINTMENT ================= */}
      {showWalkinModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-teal-400" />
                <h3 className="font-bold text-base">New Walk-in / Phone Booking</h3>
              </div>
              <button
                onClick={() => setShowWalkinModal(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateWalkin} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-800 block mb-1">Patient Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Chandra"
                  value={walkinForm.patientName}
                  onChange={(e) => setWalkinForm({ ...walkinForm, patientName: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Phone *</label>
                  <input
                    type="tel"
                    required
                    placeholder="10-digit phone"
                    value={walkinForm.patientPhone}
                    onChange={(e) => setWalkinForm({ ...walkinForm, patientPhone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Age</label>
                  <input
                    type="number"
                    value={walkinForm.patientAge}
                    onChange={(e) => setWalkinForm({ ...walkinForm, patientAge: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Date</label>
                  <input
                    type="date"
                    value={walkinForm.appointmentDate}
                    onChange={(e) => setWalkinForm({ ...walkinForm, appointmentDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-800 block mb-1">Time Slot</label>
                  <input
                    type="text"
                    placeholder="10:00 AM"
                    value={walkinForm.appointmentTime}
                    onChange={(e) => setWalkinForm({ ...walkinForm, appointmentTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">Reason for Visit</label>
                <input
                  type="text"
                  placeholder="e.g. Chest discomfort, cough, prescription follow-up"
                  value={walkinForm.reason}
                  onChange={(e) => setWalkinForm({ ...walkinForm, reason: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowWalkinModal(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl cursor-pointer"
                >
                  Create & Confirm
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
