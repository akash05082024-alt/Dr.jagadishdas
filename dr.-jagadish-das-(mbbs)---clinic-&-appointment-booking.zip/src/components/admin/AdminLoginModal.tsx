import React, { useState } from 'react';
import { Lock, Mail, Key, X, Loader2, AlertCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { loginAdmin } from '../../services/api';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (adminData: any) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [identifier, setIdentifier] = useState('admin@drjagadishdas.com');
  const [password, setPassword] = useState('DoctorSecurePass2026!');
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgotNotice, setShowForgotNotice] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier || !password) {
      setError('Please enter your admin email or registered mobile and password.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const res = await loginAdmin(identifier, password);
      if (res.success) {
        onLoginSuccess(res.admin);
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = () => {
    setIdentifier('admin@drjagadishdas.com');
    setPassword('DoctorSecurePass2026!');
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-teal-600 flex items-center justify-center text-white">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight">Doctor Admin Portal</h3>
              <p className="text-[11px] text-slate-400">Dr. Jagadish Das Clinic Dashboard</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Demo Credentials Box */}
          <div className="p-3.5 bg-teal-50/70 border border-teal-200/80 rounded-2xl text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-teal-900 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-700" /> Demo Admin Access
              </span>
              <button
                type="button"
                onClick={handleFillDemo}
                className="text-[11px] font-bold text-teal-700 underline hover:text-teal-900 cursor-pointer"
              >
                Auto-fill Demo
              </button>
            </div>
            <div className="text-slate-600 font-mono text-[11px]">
              Email: <strong>admin@drjagadishdas.com</strong>
            </div>
            <div className="text-slate-600 font-mono text-[11px]">
              Pass: <strong>DoctorSecurePass2026!</strong>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Identifier Field: Email or Mobile */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-teal-600" />
              Email / Mobile
            </label>
            <input
              type="text"
              placeholder="e.g. admin@drjagadishdas.com or 9876543210"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
              required
            />
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-teal-600" />
                Password
              </label>
              <button
                type="button"
                onClick={() => setShowForgotNotice(!showForgotNotice)}
                className="text-xs text-teal-700 hover:underline cursor-pointer"
              >
                Forgot password?
              </button>
            </div>
            <input
              type="password"
              placeholder="••••••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
              required
            />
          </div>

          {showForgotNotice && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-600 text-xs">
              Password recovery instructions can be dispatched to the doctor's registered email or WhatsApp. In development mode, use default password: <strong>DoctorSecurePass2026!</strong>
            </div>
          )}

          {/* Remember Me Checkbox */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="rememberMe"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
            />
            <label htmlFor="rememberMe" className="text-xs text-slate-600 cursor-pointer">
              Remember login credentials on this device
            </label>
          </div>

          {/* Submit Action */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 active:bg-slate-950 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-xs"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-teal-400" />
                  <span>Verifying Session...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 text-teal-400" />
                  <span>Sign In to Admin Dashboard</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
