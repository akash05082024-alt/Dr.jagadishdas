import React, { useState } from 'react';
import { Search, X, Loader2, AlertCircle, Calendar, Clock, User, CheckCircle2 } from 'lucide-react';
import { Appointment } from '../types/clinic';
import { getAppointmentDetails } from '../services/api';

interface AppointmentLookupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAppointment: (appointment: Appointment) => void;
}

export const AppointmentLookupModal: React.FC<AppointmentLookupModalProps> = ({
  isOpen,
  onClose,
  onSelectAppointment,
}) => {
  const [appointmentIdInput, setAppointmentIdInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const query = appointmentIdInput.trim().toUpperCase();
    if (!query) {
      setError('Please enter your Appointment ID (e.g. APT-2026-0001).');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const res = await getAppointmentDetails(query);
      if (res.appointment) {
        onSelectAppointment(res.appointment);
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || 'Appointment record not found. Please verify the ID.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Search className="w-5 h-5 text-teal-400" />
            <h3 className="text-base font-bold tracking-tight">Check Appointment Status</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/70 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleLookup} className="p-6 space-y-4">
          <p className="text-xs text-slate-600">
            Enter the unique Appointment ID generated when your booking was confirmed (e.g., <strong className="text-slate-900">APT-2026-0001</strong>).
          </p>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800">
              Appointment ID
            </label>
            <input
              type="text"
              placeholder="APT-2026-XXXX"
              value={appointmentIdInput}
              onChange={(e) => setAppointmentIdInput(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm uppercase tracking-wider font-mono border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600"
              autoFocus
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Searching...</span>
                </>
              ) : (
                <>
                  <Search className="w-3.5 h-3.5" />
                  <span>Lookup Booking</span>
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
