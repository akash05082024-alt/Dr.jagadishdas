import React, { useState } from 'react';
import { Menu, X, CalendarCheck, Phone, Stethoscope, Lock, Search } from 'lucide-react';

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
  onOpenBooking: () => void;
  onOpenLookup: () => void;
  onOpenAdmin: () => void;
  isAdminLoggedIn?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  onOpenBooking,
  onOpenLookup,
  onOpenAdmin,
  isAdminLoggedIn = false,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    onNavigate(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* ZONE 1: Brand Wordmark (Single text element with clean medical badge) */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2.5 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 rounded-lg p-1"
            >
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-sm group-hover:bg-teal-700 transition-colors">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-base sm:text-lg font-bold text-slate-900 tracking-tight leading-tight">
                  Dr. Jagadish Das
                </span>
                <span className="text-[11px] font-medium text-teal-700 tracking-wide">
                  MBBS · General Physician
                </span>
              </div>
            </button>
          </div>

          {/* ZONE 2: 4-6 Clean Text Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            <button
              onClick={() => handleNavClick('home')}
              className="hover:text-teal-700 transition-colors cursor-pointer"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('about-doctor')}
              className="hover:text-teal-700 transition-colors cursor-pointer"
            >
              About Doctor
            </button>
            <button
              onClick={() => handleNavClick('services')}
              className="hover:text-teal-700 transition-colors cursor-pointer"
            >
              Services
            </button>
            <button
              onClick={() => handleNavClick('clinic-location')}
              className="hover:text-teal-700 transition-colors cursor-pointer"
            >
              Clinic & Location
            </button>
            <button
              onClick={onOpenLookup}
              className="hover:text-teal-700 transition-colors cursor-pointer flex items-center gap-1.5 text-slate-500 hover:text-slate-900"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Check Booking</span>
            </button>
          </nav>

          {/* ZONE 3: 1-2 Primary Actions */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={onOpenAdmin}
              className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              title="Doctor Admin Portal"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isAdminLoggedIn ? 'Dashboard' : 'Admin Login'}</span>
            </button>

            <button
              onClick={onOpenBooking}
              className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={onOpenBooking}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 rounded-lg whitespace-nowrap"
            >
              Book Now
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white px-4 pt-2 pb-6 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex flex-col space-y-2 text-sm font-medium text-slate-700">
            <button
              onClick={() => handleNavClick('home')}
              className="px-3 py-2 rounded-md hover:bg-slate-100 text-left"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('about-doctor')}
              className="px-3 py-2 rounded-md hover:bg-slate-100 text-left"
            >
              About Dr. Jagadish Das
            </button>
            <button
              onClick={() => handleNavClick('services')}
              className="px-3 py-2 rounded-md hover:bg-slate-100 text-left"
            >
              Medical Services
            </button>
            <button
              onClick={() => handleNavClick('clinic-location')}
              className="px-3 py-2 rounded-md hover:bg-slate-100 text-left"
            >
              Clinic Address & Timings
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenLookup();
              }}
              className="px-3 py-2 rounded-md hover:bg-slate-100 text-left flex items-center gap-2 text-teal-700"
            >
              <Search className="w-4 h-4" />
              Check Appointment Status
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="px-3 py-2 rounded-md hover:bg-slate-100 text-left flex items-center gap-2 text-slate-600"
            >
              <Lock className="w-4 h-4" />
              {isAdminLoggedIn ? 'Doctor Admin Dashboard' : 'Admin Login'}
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full py-3 text-center text-sm font-semibold text-white bg-teal-600 rounded-lg shadow-sm"
            >
              Book Your Appointment Online
            </button>
            <a
              href="tel:+919876543210"
              className="w-full py-2.5 text-center text-xs font-medium text-slate-700 bg-slate-100 rounded-lg flex items-center justify-center gap-2"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              Call Clinic: +91 98765 43210
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
