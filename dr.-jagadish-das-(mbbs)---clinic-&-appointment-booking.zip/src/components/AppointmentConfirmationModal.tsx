import React, { useState } from 'react';
import {
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  Phone,
  User,
  X,
  Download,
  AlertCircle,
  Share2,
  Navigation,
  FileText,
  Printer,
  CalendarPlus,
} from 'lucide-react';
import { Appointment, ClinicSettings, DoctorProfile } from '../types/clinic';
import { cancelPatientAppointment } from '../services/api';

interface AppointmentConfirmationModalProps {
  appointment: Appointment | null;
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  isOpen: boolean;
  onClose: () => void;
  onAppointmentCancelled?: (appointment: Appointment) => void;
}

export const AppointmentConfirmationModal: React.FC<AppointmentConfirmationModalProps> = ({
  appointment,
  doctor,
  clinic,
  isOpen,
  onClose,
  onAppointmentCancelled,
}) => {
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [cancelPhoneInput, setCancelPhoneInput] = useState('');
  const [cancelLoading, setCancelLoading] = useState(false);
  const [cancelError, setCancelError] = useState<string | null>(null);
  const [isCancelled, setIsCancelled] = useState(appointment?.status === 'CANCELLED');

  if (!isOpen || !appointment) return null;

  // Add to Calendar: Generate standard Google Calendar Event URL
  const handleAddToGoogleCalendar = () => {
    try {
      const dateParts = appointment.appointmentDate.split('-'); // ["2026", "09", "28"]
      // Time format: "10:00 AM"
      const timeParts = appointment.appointmentTime.split(' ');
      const [hourMinute, ampm] = timeParts;
      let [h, m] = hourMinute.split(':').map(Number);
      if (ampm === 'PM' && h !== 12) h += 12;
      if (ampm === 'AM' && h === 12) h = 0;

      const startDate = new Date(
        parseInt(dateParts[0], 10),
        parseInt(dateParts[1], 10) - 1,
        parseInt(dateParts[2], 10),
        h,
        m
      );
      const endDate = new Date(startDate.getTime() + 30 * 60000); // 30 min duration

      const formatIso = (d: Date) =>
        d.toISOString().replace(/-|:|\.\d\d\d/g, '');

      const title = encodeURIComponent(`Consultation: Dr. Jagadish Das (${appointment.appointmentId})`);
      const details = encodeURIComponent(
        `Appointment with Dr. Jagadish Das (MBBS).\nPatient: ${appointment.patientName}\nAppointment ID: ${appointment.appointmentId}\nChamber: ${clinic.clinicName}, ${clinic.addressLine1}\nPhone: ${clinic.phonePrimary}`
      );
      const location = encodeURIComponent(`${clinic.clinicName}, ${clinic.addressLine1}, ${clinic.city}`);
      const dates = `${formatIso(startDate)}/${formatIso(endDate)}`;

      const gcalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${dates}&details=${details}&location=${location}`;
      window.open(gcalUrl, '_blank', 'noopener,noreferrer');
    } catch (e) {
      console.error('Error generating Google Calendar URL:', e);
    }
  };

  // Download .ics file
  const handleDownloadICS = () => {
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Dr Jagadish Das//Appointment System//EN',
      'BEGIN:VEVENT',
      `SUMMARY:Doctor Appointment - Dr. Jagadish Das (${appointment.appointmentId})`,
      `DESCRIPTION:Patient: ${appointment.patientName}\\nChamber: ${clinic.clinicName}\\nFee: ₹${appointment.consultationFee}`,
      `LOCATION:${clinic.clinicName}\\, ${clinic.addressLine1}\\, ${clinic.city}`,
      `STATUS:CONFIRMED`,
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `${appointment.appointmentId}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Print appointment slip
  const handlePrintSlip = () => {
    window.print();
  };

  // Cancel appointment handler
  const handleConfirmCancel = async () => {
    if (!cancelPhoneInput.trim()) {
      setCancelError('Please enter your booking mobile number to confirm cancellation.');
      return;
    }
    setCancelLoading(true);
    setCancelError(null);
    try {
      const res = await cancelPatientAppointment(appointment.appointmentId, cancelPhoneInput);
      if (res.success) {
        setIsCancelled(true);
        setShowCancelConfirm(false);
        if (onAppointmentCancelled) {
          onAppointmentCancelled(res.appointment);
        }
      }
    } catch (err: any) {
      setCancelError(err.message || 'Failed to cancel appointment. Please check your mobile number.');
    } finally {
      setCancelLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-teal-700 to-teal-800 text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-teal-200" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight">
                {isCancelled ? 'Appointment Cancelled' : 'Appointment Confirmed'}
              </h3>
              <p className="text-xs text-teal-100">
                Official Clinic Booking Slip
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-7 space-y-6">
          
          {/* Success Banner */}
          {!isCancelled ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-emerald-900">
                  Appointment booked successfully.
                </h4>
                <p className="text-xs text-emerald-700 mt-0.5">
                  A confirmation alert has been dispatched via WhatsApp & SMS. Please arrive 10–15 minutes before your scheduled slot.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3">
              <AlertCircle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-rose-900">
                  This appointment has been cancelled.
                </h4>
                <p className="text-xs text-rose-700 mt-0.5">
                  The reserved slot has been released back to the clinic calendar.
                </p>
              </div>
            </div>
          )}

          {/* Core Receipt Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4">
            
            {/* Appointment ID Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Appointment ID
                </span>
                <div className="text-lg sm:text-xl font-mono font-extrabold text-teal-800 tracking-tight">
                  {appointment.appointmentId}
                </div>
              </div>

              <div className="text-right">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Status
                </span>
                <div>
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-md text-xs font-bold ${
                      isCancelled
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {isCancelled ? 'CANCELLED' : appointment.status}
                  </span>
                </div>
              </div>
            </div>

            {/* Grid of Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
              <div>
                <span className="text-slate-500 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-teal-600" /> Patient Name
                </span>
                <span className="font-bold text-slate-900 block mt-0.5">
                  {appointment.patientName} ({appointment.patientAge}y, {appointment.patientGender})
                </span>
                <span className="text-slate-500 text-xs tabular-nums block">
                  {appointment.patientPhone}
                </span>
              </div>

              <div>
                <span className="text-slate-500 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-teal-600" /> Attending Physician
                </span>
                <span className="font-bold text-slate-900 block mt-0.5">
                  {doctor.name} ({doctor.degrees})
                </span>
                <span className="text-teal-700 text-xs block">
                  {doctor.specialization}
                </span>
              </div>

              <div>
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-600" /> Consultation Date
                </span>
                <span className="font-bold text-slate-900 block mt-0.5">
                  {new Date(`${appointment.appointmentDate}T00:00:00`).toLocaleDateString('en-US', {
                    weekday: 'short',
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </span>
              </div>

              <div>
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-teal-600" /> Scheduled Time Slot
                </span>
                <span className="font-extrabold text-teal-800 block mt-0.5">
                  {appointment.appointmentTime}
                </span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-teal-600" /> Clinic Chamber Address
                </span>
                <span className="font-bold text-slate-900 block mt-0.5">
                  {clinic.clinicName}
                </span>
                <span className="text-slate-600 text-xs block">
                  {clinic.addressLine1}, {clinic.landmark}, {clinic.city} - {clinic.pincode}
                </span>
              </div>

              <div>
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-teal-600" /> Chamber Desk Contact
                </span>
                <span className="font-bold text-slate-900 block mt-0.5 tabular-nums">
                  {clinic.phonePrimary}
                </span>
              </div>

              <div>
                <span className="text-slate-500">Consultation Fee</span>
                <span className="font-extrabold text-slate-900 block mt-0.5 tabular-nums">
                  ₹{appointment.consultationFee} <span className="text-xs font-normal text-slate-500">(Pay at desk)</span>
                </span>
              </div>

              <div className="sm:col-span-2 pt-1 border-t border-slate-200/80">
                <span className="text-slate-500 text-xs">Reason for Visit: </span>
                <span className="font-medium text-slate-800 text-xs">{appointment.reason}</span>
              </div>
            </div>

          </div>

          {/* Cancellation Confirmation Drawer */}
          {showCancelConfirm && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center gap-2 text-rose-900 font-bold text-xs sm:text-sm">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Confirm Appointment Cancellation</span>
              </div>
              <p className="text-xs text-rose-700">
                Please enter the 10-digit mobile number used during booking to verify cancellation:
              </p>
              <div className="flex items-center gap-2">
                <input
                  type="tel"
                  placeholder="Enter your phone number"
                  value={cancelPhoneInput}
                  onChange={(e) => setCancelPhoneInput(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs border border-rose-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
                <button
                  disabled={cancelLoading}
                  onClick={handleConfirmCancel}
                  className="px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg cursor-pointer"
                >
                  {cancelLoading ? 'Cancelling...' : 'Confirm'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowCancelConfirm(false)}
                  className="px-2.5 py-2 text-xs text-slate-600 hover:text-slate-900"
                >
                  Back
                </button>
              </div>
              {cancelError && (
                <div className="text-xs text-rose-800 font-medium">{cancelError}</div>
              )}
            </div>
          )}

          {/* REQUIRED BUTTONS: [Add to Calendar], [Call Clinic], [Get Directions], [Cancel Appointment] */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
            
            {/* Add to Calendar */}
            <div className="relative group">
              <button
                onClick={handleAddToGoogleCalendar}
                className="w-full py-2.5 px-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-teal-50 hover:text-teal-800 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <CalendarPlus className="w-3.5 h-3.5 text-teal-600" />
                <span>Add to Calendar</span>
              </button>
            </div>

            {/* Call Clinic */}
            <a
              href={`tel:${clinic.phonePrimary.replace(/\s+/g, '')}`}
              className="w-full py-2.5 px-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-teal-50 hover:text-teal-800 rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              <span>Call Clinic</span>
            </a>

            {/* Get Directions */}
            <a
              href={clinic.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-teal-50 hover:text-teal-800 rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <Navigation className="w-3.5 h-3.5 text-teal-600" />
              <span>Get Directions</span>
            </a>

            {/* Cancel Appointment */}
            {!isCancelled && !showCancelConfirm ? (
              <button
                onClick={() => setShowCancelConfirm(true)}
                className="w-full py-2.5 px-2 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Cancel</span>
              </button>
            ) : (
              <button
                onClick={handlePrintSlip}
                className="w-full py-2.5 px-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Slip</span>
              </button>
            )}

          </div>

          {/* Done CTA */}
          <div className="pt-2">
            <button
              onClick={onClose}
              className="w-full py-3 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              Done / Return to Home
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
