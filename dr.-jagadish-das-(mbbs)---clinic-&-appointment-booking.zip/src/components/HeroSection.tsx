import React from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Phone,
  ShieldCheck,
  Award,
  Navigation,
  CheckCircle2,
  Users,
} from 'lucide-react';
import { DoctorAvatar } from './DoctorAvatar';
import { DoctorProfile, ClinicSettings } from '../types/clinic';

interface HeroSectionProps {
  doctor: DoctorProfile;
  clinic: ClinicSettings;
  timingsText: string;
  onBookClick: () => void;
  onDirectionsClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  doctor,
  clinic,
  timingsText,
  onBookClick,
  onDirectionsClick,
}) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-teal-50/50 via-white to-slate-50 pt-8 pb-16 sm:py-16 lg:py-20 border-b border-slate-200/80">
      {/* Subtle background decorative shapes */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-100/40 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-cyan-100/30 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* LEFT COLUMN: Main Value Proposition & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Unboxed Metadata Trust Bar (Clean typographic separators per anti-slop rule) */}
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-medium text-slate-600">
              <span className="text-teal-700 font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-teal-600" />
                Verified Medical Practitioner
              </span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>Reg: {doctor.registrationNumber || 'WBMC Registered'}</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="text-slate-700 font-semibold">{doctor.experienceYears}+ Years Clinical Practice</span>
            </div>

            {/* Dominant Headline */}
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-5xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight sm:leading-tight">
                Book Your Appointment <span className="text-teal-700">Online</span>
              </h1>
              <p className="text-lg sm:text-xl font-medium text-slate-700 leading-snug">
                Personalized, evidence-based outpatient consultations with <span className="text-slate-900 font-semibold">{doctor.name} ({doctor.degrees})</span>.
              </p>
            </div>

            {/* Short Intro / Description */}
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
              Receive timely medical advice for acute infections, fever, hypertension, diabetes, routine wellness examinations, and chronic health concerns in a clean, professional clinical chamber.
            </p>

            {/* Quick Clinic Summary Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 pb-2">
              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200/90 shadow-xs">
                <Clock className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Consultation Hours</div>
                  <div className="text-sm font-semibold text-slate-800">{timingsText || 'Mon–Sat: 10AM–1PM & 5PM–8PM'}</div>
                  <div className="text-[11px] text-slate-500">Sunday Closed · In-person Chamber</div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200/90 shadow-xs">
                <MapPin className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Chamber Location</div>
                  <div className="text-sm font-semibold text-slate-800 line-clamp-1">{clinic.clinicName}</div>
                  <div className="text-[11px] text-slate-500 line-clamp-1">{clinic.addressLine1}, {clinic.city}</div>
                </div>
              </div>
            </div>

            {/* CTAs: Primary [Book Appointment], Secondary [Call Now], Tertiary [Get Directions] */}
            <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={onBookClick}
                className="w-full sm:w-auto px-7 py-3.5 text-base font-bold text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600"
              >
                <Calendar className="w-5 h-5" />
                <span>Book Appointment</span>
              </button>

              <a
                href={`tel:${clinic.phonePrimary.replace(/\s+/g, '')}`}
                className="w-full sm:w-auto px-5 py-3.5 text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Phone className="w-4 h-4 text-teal-600" />
                <span>Call Clinic Now</span>
              </a>

              <button
                onClick={onDirectionsClick}
                className="w-full sm:w-auto px-4 py-3.5 text-sm font-semibold text-slate-600 hover:text-teal-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Navigation className="w-4 h-4 text-teal-600" />
                <span>Get Directions</span>
              </button>
            </div>

            {/* Reassurance points */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-5 text-xs text-slate-500 pt-1">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Instant SMS & WhatsApp Confirmation
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Zero Double-Booking Lock
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Consultation Fee: ₹{doctor.consultationFee}
              </span>
            </div>

          </div>

          {/* RIGHT COLUMN: Doctor Profile Card Showcase */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="w-full max-w-md bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-xl relative">
              
              {/* Top Accent Strip */}
              <div className="flex items-center justify-between pb-5 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-semibold text-slate-700 tracking-wide uppercase">
                    Accepting Patients Today
                  </span>
                </div>
                <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-md border border-teal-200/60">
                  Fee: ₹{doctor.consultationFee}
                </span>
              </div>

              {/* Portrait & Core Doctor Credentials */}
              <div className="pt-6 flex flex-col items-center text-center">
                <DoctorAvatar size="xl" showBadge={true} />

                <div className="mt-4 space-y-1">
                  <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                    {doctor.name}
                  </h2>
                  <div className="text-sm font-semibold text-teal-700">
                    {doctor.degrees} · {doctor.specialization}
                  </div>
                  <div className="text-xs text-slate-500">
                    Reg. No: {doctor.registrationNumber}
                  </div>
                </div>

                {/* Key Stats Counter Grid */}
                <div className="grid grid-cols-3 gap-2 w-full mt-6 pt-5 border-t border-slate-100 text-center">
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <div className="text-lg font-bold text-slate-900 tabular-nums">12+</div>
                    <div className="text-[11px] font-medium text-slate-500">Yrs Exp.</div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <div className="text-lg font-bold text-slate-900 tabular-nums">18k+</div>
                    <div className="text-[11px] font-medium text-slate-500">Consultations</div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <div className="text-lg font-bold text-teal-700 tabular-nums">100%</div>
                    <div className="text-[11px] font-medium text-slate-500">Verified MBBS</div>
                  </div>
                </div>

                {/* Direct Action Inside Card */}
                <button
                  onClick={onBookClick}
                  className="mt-6 w-full py-3 px-4 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-teal-400" />
                  <span>Select Date & Book Slot</span>
                </button>

                <p className="text-[11px] text-slate-400 mt-2">
                  No payment required to book · Pay consultation fee at clinic
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
