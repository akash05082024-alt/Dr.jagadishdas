import React from 'react';
import {
  Activity,
  HeartPulse,
  Thermometer,
  ShieldAlert,
  ClipboardList,
  Baby,
  Pill,
  FileCheck,
  Calendar,
} from 'lucide-react';

interface ServicesSectionProps {
  onBookClick: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onBookClick }) => {
  const serviceCards = [
    {
      title: 'General Medical Consultations',
      desc: 'Diagnosis and clinical management of acute ailments, chronic health issues, fatigue, body aches, and constitutional symptoms.',
      icon: Activity,
    },
    {
      title: 'Hypertension & Cardiac Screening',
      desc: 'Accurate blood pressure monitoring, cardiovascular risk stratification, lipid profiling review, and preventive management.',
      icon: HeartPulse,
    },
    {
      title: 'Diabetes & Metabolic Care',
      desc: 'Fasting and postprandial glucose tracking, HbA1c review, insulin and oral medication monitoring, and diet guidance.',
      icon: ClipboardList,
    },
    {
      title: 'Fever, Flu & Viral Illnesses',
      desc: 'Timely evaluation of acute seasonal viral fevers, typhoid, dengue screening, throat infections, and chest symptoms.',
      icon: Thermometer,
    },
    {
      title: 'Routine Health Checkups',
      desc: 'Periodic preventative health screenings for working adults, senior citizens, and lifestyle disease risk reduction.',
      icon: ShieldAlert,
    },
    {
      title: 'Pediatric & Geriatric Outpatient',
      desc: 'Gentle outpatient care for children and elderly patients with multiple comorbidities and chronic medication review.',
      icon: Baby,
    },
    {
      title: 'Prescription & Lab Interpretation',
      desc: 'Second opinion on laboratory blood tests, ultrasound/X-ray reports, and rationalized medication review.',
      icon: Pill,
    },
    {
      title: 'Medical Certificates & Fitness',
      desc: 'Standard physical fitness assessments and verified clinical medical examination certificates where applicable.',
      icon: FileCheck,
    },
  ];

  return (
    <section id="services" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-teal-700">
            Clinical Specialization & Care Scope
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Comprehensive Family Healthcare Services
          </h2>
          <p className="text-base text-slate-600">
            Professional outpatient medical evaluations by Dr. Jagadish Das (MBBS) designed for timely diagnosis and patient well-being.
          </p>
        </div>

        {/* Bento Grid of 8 Services */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {serviceCards.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 border border-slate-200/90 hover:border-teal-400 hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 group-hover:bg-teal-600 group-hover:text-white transition-colors flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-2 leading-snug">
                    {service.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {service.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="font-semibold text-teal-700">In-Chamber Care</span>
                  <span className="text-slate-400 tabular-nums">0{index + 1}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Clean Consultation Notice */}
        <div className="mt-12 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xs">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-lg font-bold text-slate-900">
              Need to Consult with Dr. Jagadish Das?
            </h4>
            <p className="text-sm text-slate-600">
              Online appointments help maintain minimal waiting times at the clinic chamber.
            </p>
          </div>

          <button
            onClick={onBookClick}
            className="px-6 py-3 text-sm font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 shrink-0 cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>Select Slot & Book Online</span>
          </button>
        </div>

      </div>
    </section>
  );
};
