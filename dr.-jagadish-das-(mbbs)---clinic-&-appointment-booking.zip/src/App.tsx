import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { DoctorProfileSection } from './components/DoctorProfileSection';
import { ServicesSection } from './components/ServicesSection';
import { BookingSection } from './components/BookingSection';
import { ClinicInfoSection } from './components/ClinicInfoSection';
import { AppointmentConfirmationModal } from './components/AppointmentConfirmationModal';
import { AppointmentLookupModal } from './components/AppointmentLookupModal';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Footer } from './components/Footer';
import { DoctorProfile, ClinicSettings, Appointment } from './types/clinic';
import { fetchPublicClinicData, getStoredToken } from './services/api';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Clinic and Doctor Profile Data
  const [doctor, setDoctor] = useState<DoctorProfile | null>(null);
  const [clinic, setClinic] = useState<ClinicSettings | null>(null);
  const [timingsSummary, setTimingsSummary] = useState<string>('Mon–Sat: 10:00 AM – 01:00 PM & 05:00 PM – 08:00 PM');

  // Modals & Navigation state
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [isLookupOpen, setIsLookupOpen] = useState(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);

  // Admin Dashboard Mode
  const [isAdminView, setIsAdminView] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  // Load public clinic data on boot
  useEffect(() => {
    async function loadData() {
      try {
        const res = await fetchPublicClinicData();
        setDoctor(res.doctor);
        setClinic(res.clinic);
        if (res.availabilitySummary?.workingDaysText) {
          setTimingsSummary(`${res.availabilitySummary.workingDaysText}: 10:00 AM – 01:00 PM & 05:00 PM – 08:00 PM`);
        }
      } catch (err: any) {
        console.error('Error fetching clinic data:', err);
        setError('Failed to connect to clinic server. Please refresh.');
      } finally {
        setLoading(false);
      }
    }
    loadData();

    // Check existing admin token
    const token = getStoredToken();
    if (token) {
      setIsAdminLoggedIn(true);
    }

    // Check if URL has /admin/login or #admin
    if (window.location.pathname.includes('/admin/login') || window.location.hash.includes('admin')) {
      if (token) {
        setIsAdminView(true);
      } else {
        setIsAdminLoginOpen(true);
      }
    }
  }, []);

  const scrollToSection = (sectionId: string) => {
    if (isAdminView) {
      setIsAdminView(false);
    }
    setTimeout(() => {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else if (sectionId === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 50);
  };

  const handleBookingSuccess = (appointment: Appointment) => {
    setConfirmedAppointment(appointment);
    setIsConfirmationOpen(true);
  };

  const handleLookupSelect = (appointment: Appointment) => {
    setConfirmedAppointment(appointment);
    setIsConfirmationOpen(true);
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setIsAdminView(true);
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setIsAdminView(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 text-center">
        <Loader2 className="w-10 h-10 animate-spin text-teal-600 mb-4" />
        <h2 className="text-lg font-bold text-slate-900">Dr. Jagadish Das, MBBS</h2>
        <p className="text-xs text-slate-500 mt-1">Connecting to clinic consultation portal...</p>
      </div>
    );
  }

  if (error || !doctor || !clinic) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 text-center">
        <div className="max-w-md bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <h2 className="text-base font-bold text-slate-900">Unable to Load Clinic Information</h2>
          <p className="text-xs text-slate-600">{error || 'Please check your connection and reload.'}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-teal-600 text-white rounded-lg text-xs font-bold"
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }

  // If in Admin Dashboard View
  if (isAdminView && isAdminLoggedIn) {
    return (
      <AdminDashboard
        onLogout={handleAdminLogout}
        onViewWebsite={() => setIsAdminView(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      
      {/* Primary Top Bar adhering to the Top Bar contract */}
      <Navbar
        onNavigate={scrollToSection}
        onOpenBooking={() => scrollToSection('book-appointment')}
        onOpenLookup={() => setIsLookupOpen(true)}
        onOpenAdmin={() => {
          if (isAdminLoggedIn) {
            setIsAdminView(true);
          } else {
            setIsAdminLoginOpen(true);
          }
        }}
        isAdminLoggedIn={isAdminLoggedIn}
      />

      {/* Main Content Sections */}
      <main id="home" className="flex-1">
        
        {/* Section 1: Hero & Value Proposition */}
        <HeroSection
          doctor={doctor}
          clinic={clinic}
          timingsText={timingsSummary}
          onBookClick={() => scrollToSection('book-appointment')}
          onDirectionsClick={() => scrollToSection('clinic-location')}
        />

        {/* Section 2: Detailed Doctor Profile Page / Section */}
        <DoctorProfileSection
          doctor={doctor}
          clinic={clinic}
          timingsText={timingsSummary}
          onBookClick={() => scrollToSection('book-appointment')}
        />

        {/* Section 3: Clinical Services Offered */}
        <ServicesSection
          onBookClick={() => scrollToSection('book-appointment')}
        />

        {/* Section 4: Real-time Online Appointment Booking Wizard */}
        <BookingSection
          doctor={doctor}
          clinic={clinic}
          onBookingSuccess={handleBookingSuccess}
        />

        {/* Section 5: Clinic Information & Directions */}
        <ClinicInfoSection
          clinic={clinic}
          doctor={doctor}
          timingsText={timingsSummary}
          onBookClick={() => scrollToSection('book-appointment')}
        />

      </main>

      {/* Footer */}
      <Footer
        doctor={doctor}
        clinic={clinic}
        onOpenAdmin={() => {
          if (isAdminLoggedIn) {
            setIsAdminView(true);
          } else {
            setIsAdminLoginOpen(true);
          }
        }}
        onOpenBooking={() => scrollToSection('book-appointment')}
        onOpenLookup={() => setIsLookupOpen(true)}
      />

      {/* MODAL 1: Appointment Confirmation / Verified Receipt View */}
      <AppointmentConfirmationModal
        isOpen={isConfirmationOpen}
        appointment={confirmedAppointment}
        doctor={doctor}
        clinic={clinic}
        onClose={() => setIsConfirmationOpen(false)}
        onAppointmentCancelled={(updatedApt) => setConfirmedAppointment(updatedApt)}
      />

      {/* MODAL 2: Existing Appointment Lookup */}
      <AppointmentLookupModal
        isOpen={isLookupOpen}
        onClose={() => setIsLookupOpen(false)}
        onSelectAppointment={handleLookupSelect}
      />

      {/* MODAL 3: Admin Login Modal (/admin/login) */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
      />

    </div>
  );
}
